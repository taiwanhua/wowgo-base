# E4 recorded formal evidence

Run `node verify.mjs` with Node 20 or later; no dependencies, Figma access or original checkout are required. Files retain their original bytes. Historical absolute paths inside records are informational; all packaged files resolve through manifest.json.

This package contains recorded migration and verification results. It does not replay writes or run another test matrix. See manifest.json for complete and pending scope.
