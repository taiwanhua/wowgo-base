// Built-in Node verification of recorded artifacts; never executes Figma scripts.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const dir=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(path.join(dir,p),'utf8'));
const canonical=o=>o===null||typeof o!=='object'?JSON.stringify(o):Array.isArray(o)?'['+o.map(canonical).join(',')+']':'{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canonical(o[k])).join(',')+'}';
const manifest=read('manifest.json');
for(const f of manifest.files){const p=path.resolve(dir,f.name);assert.ok(p.startsWith(dir+path.sep));const b=fs.readFileSync(p);assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256,f.name)}
for(const item of manifest.references){const p=read('evidence/'+item.proof);const d=read('evidence/'+item.decoded);let r=read('evidence/'+item.raw);if(r.content)r=JSON.parse(r.content.find(c=>c.type==='text').text);assert.equal(r.codec,'gzip-base64');const bytes=gunzipSync(Buffer.from(r.payload,'base64'));assert.equal(bytes.length,r.utf8Bytes);assert.equal(sha(bytes),r.sha256);assert.equal(sha(canonical(d)),r.sha256);assert.equal(p.decodedDigest,r.sha256);assert.equal(d.protectedNodes.ok,true);assert.equal(d.protectedNodes.actualDigest,d.protectedNodes.expectedDigest);assert.deepEqual(d.errors,[]);assert.equal(d.unknownMutations,false);assert.equal(d.foundationClosureComplete,item.complete)}
assert.equal(manifest.sharedMovePages,27);assert.equal(manifest.sharedFoundation.status,'verified');assert.equal(manifest.sharedFoundation.verifiedSlots,1591);assert.equal(manifest.sharedFoundation.unresolved,0);
for(const item of manifest.recoveries??[]){const stem='evidence/'+item.stem,proof=read(stem+'.proof.json'),raw=read(stem+'.raw.json'),value=read(stem+'.decoded.json'),config=read(stem+'.config.json');const bytes=gunzipSync(Buffer.from(raw.payload,'base64'));assert.equal(sha(bytes),raw.sha256);assert.equal(sha(canonical(value)),raw.sha256);assert.equal(raw.sha256,proof.decodedDigest);assert.equal(sha(fs.readFileSync(path.join(dir,stem+'.config.json'))),proof.configSha256);assert.equal(value.status,item.status);assert.equal(value.foundationClosureComplete,item.complete);assert.equal(value.priorCompletedExactLocal,true);assert.equal(value.allBindingsExactLocal,item.complete);assert.equal(value.destinationMetadataVerified,true);assert.equal(value.protectedNodes.actualCanonicalDigest,config.approvedDestinationDigest);if(item.complete)assert.equal(value.remainingCount,0);else{assert.equal(value.status,'recovered-unapplied-exact');assert.equal(value.remainingCount,config.batch.expectedRemainingOpsCount);assert.equal(value.remainingDigest,config.batch.expectedRemainingOpsDigest);}assert.equal(value.canvasWritesThisCall,0);assert.equal(value.interruptedWriteCountKnown,false);assert.deepEqual(value.mutatedNodeIds,[]);}
process.stdout.write(JSON.stringify({ok:true,verifiedRecordedFiles:manifest.files.length,verifiedReferencePackets:manifest.references.length,completeReferencePages:manifest.completeReferencePages.length,expectedReferencePages:manifest.expectedReferencePages,limitations:manifest.limitations})+'\n');
