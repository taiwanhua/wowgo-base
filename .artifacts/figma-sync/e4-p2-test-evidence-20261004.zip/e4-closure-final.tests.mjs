/** Scratch-only actual MOVE + foundation rebind proof. No Figma/raw capture writes.
 * Run: node .codex/e4-closure-final.tests.mjs
 * Writes only the new e4-closure-final.classified.json report.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { compareReferenceCopy } from './e4-compare-reference-copy.mjs';
const path = name => new URL('./' + name, import.meta.url);
const read = name => JSON.parse(readFileSync(path(name), 'utf8'));
const hash = name => createHash('sha256').update(readFileSync(path(name))).digest('hex');
const names = ['e4-closure-before.json', 'e4-closure-moved.json', 'e4-closure-after.json', 'e4-test-foundations-proof.json', 'e4-closure-move-identities.json', 'e4-closure-move.classified.json', 'e4-closure-rebind-result.json'];
const hashes = Object.fromEntries(names.map(n => [n, hash(n)]));
const before = read(names[0]), moved = read(names[1]), after = read(names[2]), proof = read(names[3]);
const prior = read(names[5]), writeEvidence = read(names[6]);
const approvals = { ...prior.approvals, foundationProof: proof };
const rebindApprovals = { ...approvals, sourceFileKey: moved.summary.fileKey,
  roots: moved.summary.roots.map(x => ({ sourceId: x.id, destinationId: x.id })), componentPairs: [], allowRootTranslation: false };
const run = (right = after, allowed = approvals, left = before) => compareReferenceCopy({ before: left, after: right, approvals: allowed });
const sourceToFinal = run(), movedToFinal = run(after, rebindApprovals, moved);
const moveRegression = run(moved, prior.approvals);
const tests = [];
for (const [name, result] of [['actual source-before to final', sourceToFinal], ['actual moved to final with zero root translation allowed', movedToFinal], ['actual move-only regression still requires unchanged foundation keys', moveRegression]]) {
  assert.equal(result.ok, true, name + JSON.stringify({ diffs: result.diffs.slice(0, 8), unresolved: result.unresolved.slice(0, 8) }));
  assert.equal(result.counts.mappedNodes, 149); assert.equal(result.counts.instances, 40);
  tests.push({ name, passed: true, counts: result.counts });
}
assert.equal(after.variables.length, 19); assert.equal(after.collections.length, 4); assert.equal(after.styles.length, 1);
for (const result of [sourceToFinal, movedToFinal]) {
  assert.equal(result.foreignFoundations.length, 0); assert.equal(result.foreignUsages.length, 0);
}
assert.equal(after.nodes.filter(x => x.main?.remote).length, 0);
assert.equal(after.nodes.filter(x => x.text).length, 46);
assert.equal(after.nodes.filter(x => x.geometry.visible === false).length, 28);
assert.deepEqual(after.summary.ancestors[0].modes.explicitVariableModes, {});
for (const n of after.nodes) assert.deepEqual(n.properties.explicitVariableModes, {});
assert.equal(writeEvidence.operationCount, 26); assert.equal(writeEvidence.completed.length, 26);
assert.equal(writeEvidence.readBack.length, 26); assert.deepEqual(writeEvidence.errors, []);
assert.ok(writeEvidence.readBack.every(x => x.ok && x.local));
tests.push({ name: 'captured final inventory is all local with 46 text / 28 hidden nodes and 26 successful setter readbacks', passed: true });
function reject(name, mutate, rebind = false) {
  const right = structuredClone(after), ap = structuredClone(rebind ? rebindApprovals : approvals);
  mutate(right, ap);
  const result = run(right, ap, rebind ? moved : before);
  assert.equal(result.ok, false, name + ' incorrectly passed');
  tests.push({ name, passed: true, diffs: result.diffs.length, unresolved: result.unresolved.length });
}
const color = x => x.collections.find(c => c.name === 'Color');
const semanticColor = x => x.variables.find(v => v.name === 'text/secondary');
const literalColor = x => x.variables.find(v => Object.values(v.valuesByMode).some(value => typeof value.r === 'number'));
reject('foundation key migration fails without captured approval', (_, ap) => { delete ap.foundationProof; });
reject('missing required foundation pair fails', (_, ap) => { ap.foundationProof.maps.variables = ap.foundationProof.maps.variables.filter(p => p.source.name !== 'radius/sm'); });
reject('duplicate foundation source keys fail', (_, ap) => { ap.foundationProof.maps.variables.push(structuredClone(ap.foundationProof.maps.variables[0])); });
reject('foundation proof with known metadata differences fails', (_, ap) => { ap.foundationProof.diffs.push({ changed: 'codeSyntax' }); });
reject('proof from another destination file fails', (_, ap) => { ap.foundationProof.destinationFileKey = 'wrong-file'; });
reject('unapproved component MOVE key still fails', (_, ap) => { ap.componentPairs.pop(); });
reject('mapped destination is not permitted to stay remote', x => { x.variables[0].remote = true; x.variables[0].hiddenFromPublishing = true; });
reject('mapped collection is not permitted to stay remote', x => { x.collections[0].remote = true; x.collections[0].hiddenFromPublishing = true; });
reject('same-key main becoming remote fails', x => { const id = x.nodes.find(n => n.main).main.id; for (const n of x.nodes) if (n.main?.id === id) n.main.remote = true; });
reject('approved key does not waive literal color changes', x => { Object.values(literalColor(x).valuesByMode).find(v => typeof v.r === 'number').r += 0.01; });
reject('approved key does not waive numeric radius changes', x => { const v = x.variables.find(v => v.name === 'radius/sm'); v.valuesByMode[Object.keys(v.valuesByMode)[0]] += 1; });
reject('Dark-only alias target changes fail', x => { const v = semanticColor(x), c = color(x); v.valuesByMode[c.modes.find(m => m.name === 'Dark').modeId].id = v.valuesByMode[c.modes.find(m => m.name === 'Light').modeId].id; });
reject('equal-color literal cannot replace alias identity', x => { const v = semanticColor(x), mode = color(x).modes[0].modeId, target = x.variables.find(a => a.id === v.valuesByMode[mode].id); v.valuesByMode[mode] = structuredClone(Object.values(target.valuesByMode)[0]); });
reject('unknown alias is unresolved', x => { semanticColor(x).valuesByMode[color(x).modes[0].modeId].id = 'VariableID:UNKNOWN'; });
reject('codeSyntax metadata change fails', x => { x.variables[0].codeSyntax.WEB = 'wrong'; });
reject('collection default mode change fails', x => { color(x).defaultModeId = color(x).modes[1].modeId; });
reject('collection mode name change fails', x => { color(x).modes[1].name = 'Incorrect'; });
reject('resolved mode Light to Dark fails', x => { const c = color(x), n = x.nodes.find(n => Object.hasOwn(n.properties.resolvedVariableModes, c.id)); n.properties.resolvedVariableModes[c.id] = c.modes[1].modeId; });
reject('new explicit Light override fails even with unchanged effective appearance', x => { const c = color(x); x.nodes[0].properties.explicitVariableModes[c.id] = c.modes[0].modeId; });
reject('new explicit PAGE mode fails', x => { const c = color(x); x.summary.ancestors[0].modes.explicitVariableModes[c.id] = c.modes[0].modeId; });
reject('style font variation change fails', x => { x.styles[0].fontName.variationSettings.wght += 100; });
reject('unbound original text cannot gain a style', x => { x.nodes.find(n => n.text?.textStyleId === '').text.textStyleId = x.styles[0].id; });
reject('live text characters change fails', x => { x.nodes.find(n => n.text).text.characters += '!'; });
reject('live text font override change fails', x => { x.nodes.find(n => n.text).text.fontName.variationSettings.wght += 100; });
reject('hidden node visibility change fails', x => { x.nodes.find(n => n.geometry.visible === false).geometry.visible = true; });
reject('existing instance override removal fails', x => { x.nodes.find(n => n.componentProperties?.overrides?.length).componentProperties.overrides.pop(); });
reject('new inherited instance override fails', x => { x.nodes.find(n => n.componentProperties?.overrides?.length).componentProperties.overrides[0].overriddenFields.push('fills'); });
reject('component property suffix change fails', x => { x.nodes.find(n => n.properties.componentPropertyReferences?.characters).properties.componentPropertyReferences.characters += '-wrong'; });
reject('descendant geometry change fails', x => { x.nodes.find(n => n.path.length > 0).geometry.width += 1; });
reject('rebind-only root translation fails', x => { x.nodes.find(n => n.path.length === 0).geometry.x += 1; }, true);
{
  const left = structuredClone(before);
  left.variables.find(x => x.remote && x.name === 'primary/main').hiddenFromPublishing = false;
  const result = run(after, approvals, left);
  assert.equal(result.ok, false, 'A malformed remote source handle was masked by a mapped local source sibling');
  tests.push({ name: 'every mapped source handle must preserve valid hidden transport even when a local sibling exists', passed: true, diffs: result.diffs.length, unresolved: result.unresolved.length });
}
const regressionProcess = spawnSync(process.execPath, [fileURLToPath(path('e4-reference-copy.tests.mjs'))], { encoding: 'utf8' });
assert.equal(regressionProcess.status, 0, regressionProcess.stderr || regressionProcess.stdout);
const referenceRegression = JSON.parse(regressionProcess.stdout);
assert.equal(referenceRegression.tests, 39); assert.equal(referenceRegression.passed, 39);
for (const name of names) assert.equal(hash(name), hashes[name], 'Captured input changed: ' + name);
const report = {
  stage: 'actual three-owner closure MOVE and foundation rebind final verification',
  inputSha256: hashes,
  comparatorSha256: hash('e4-compare-reference-copy.mjs'),
  approvals, rebindApprovals,
  sourceToFinal, movedToFinal,
  finalInventory: { ...after.summary.counts, hiddenNodes: 28, remoteMains: 0, foreignFoundations: 0, foreignUsages: 0, rebindWrites: 26, pageId: after.summary.pageId },
  tests, referenceRegression,
  limits: ['Only the captured 149-node three-owner closure; not yet the 413-node reference recopy or all 51 owners', 'Mode handles are preserved in classified raw differences; semantic modes and explicit overrides remain exact', 'No writes to Figma, raw captures, production code, or earlier reports'],
};
writeFileSync(path('e4-closure-final.classified.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify({ ok: true, tests: tests.length, passed: tests.length, referenceRegression: referenceRegression.passed, sourceToFinal: sourceToFinal.counts, movedToFinal: movedToFinal.counts, report: 'e4-closure-final.classified.json' }, null, 2) + '\n');
