/** Pure local fixtures for the one-time E4 comparator. Does not write captures/Figma.
 * Run: node .codex/e4-reference-copy.tests.mjs
 * The passing fixture is SYNTHETIC locality repair, not evidence of live Figma repair.
 */
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { compareReferenceCopy } from './e4-compare-reference-copy.mjs';
const file = name => new URL('./e4-reference-' + name + '.json', import.meta.url);
const inputNames = ['before', 'after', 'approvals', 'comparison'];
const hash = name => createHash('sha256').update(readFileSync(file(name))).digest('hex');
const hashes = Object.fromEntries(inputNames.map(name => [name, hash(name)]));
const before = JSON.parse(readFileSync(file('before'), 'utf8'));
const capturedAfter = JSON.parse(readFileSync(file('after'), 'utf8'));
const approvals = JSON.parse(readFileSync(file('approvals'), 'utf8'));
const run = (after, left = before, ap = approvals) => compareReferenceCopy({ before: left, after, approvals: ap });
const results = [];
const captured = run(capturedAfter);
assert.equal(captured.ok, false);
assert.equal(captured.counts.semanticDiffs, 0);
assert.equal(captured.counts.localityDiffs, 23);
assert.equal(captured.counts.unresolved, 0);
assert.equal(captured.diffs.filter(x => x.at.startsWith('node/path/')).length, 17);
results.push({ name: 'captured copy keeps all 17 main + 4 variable + 2 collection locality failures', passed: true, counts: captured.counts });
const passing = structuredClone(capturedAfter);
for (const [kind, list] of [['variables', 'localVariableKeys'], ['collections', 'localCollectionKeys'], ['styles', 'localStyleKeys']]) {
  const keys = new Set(approvals[list]);
  for (const row of passing[kind]) if (keys.has(row.key)) {
    row.remote = false;
    if (Object.hasOwn(row, 'hiddenFromPublishing')) row.hiddenFromPublishing = false;
  }
}
for (const n of passing.nodes) if (n.main && approvals.localComponentKeys.includes(n.main.key)) n.main.remote = false;
const pass = run(passing);
assert.equal(pass.ok, true, JSON.stringify({ diffs: pass.diffs.slice(0, 3), unresolved: pass.unresolved.slice(0, 3) }));
const duplicates = pass.mappings.assets.filter(x => x.after.length > 1);
assert.equal(duplicates.length, 7);
assert.equal(duplicates.find(x => x.kind === 'styles').after.length, 2);
assert.ok(pass.representationChanges.some(x => x.category === 'resolvedVariableModes'));
assert.ok(pass.representationChanges.some(x => x.category === 'hiddenFromPublishing'));
assert.equal(pass.mappings.mains.length, 84);
results.push({ name: 'SYNTHETIC repaired locality: same-key multiple local handles, mode ID representations and root copy pass', passed: true, counts: pass.counts });
function reject(name, mutate, category = 'semantic') {
  const after = structuredClone(passing), left = structuredClone(before), ap = structuredClone(approvals);
  mutate(after, left, ap);
  const r = run(after, left, ap);
  assert.equal(r.ok, false, name + ' incorrectly passed');
  if (category === 'unresolved') assert.ok(r.unresolved.length > 0, name + ' did not retain unresolved identity');
  else assert.ok(r.diffs.some(x => x.category === category), name + ' lacked ' + category + ' failure');
  results.push({ name, passed: true, diffs: r.counts.diffs, semanticDiffs: r.counts.semanticDiffs, localityDiffs: r.counts.localityDiffs, unresolved: r.counts.unresolved });
}
const sourceMain = 'babe57f54adcfbcc3d99f2fa7d921d3b415feb55';
const baseMain = '45ab2a7ff691104c8618279eead41edd28ec95be';
const sourceBrandMain = 'f90f24118e6a36f7a3997680457792c29348a719';
const baseBrandMain = '5fbe703ad1f9d781212556b35b2fe7896d55e2d6';
const baseColor = '9bbd88f67891ed2b2ac84da91e4a277570b31e03';
const pick = (a, key) => a.variables.find(x => x.key === key);
reject('literal color changes', a => { pick(a, sourceBrandMain).valuesByMode['6:0'].r += 0.01; });
reject('Dark-only alias changes to an existing same-value base brand key', a => { pick(a, sourceMain).valuesByMode['6:3'].id = pick(a, baseBrandMain).id; });
reject('alias replaced by its equal literal color', a => { pick(a, sourceMain).valuesByMode['6:2'] = structuredClone(pick(a, sourceBrandMain).valuesByMode['6:0']); });
reject('alias target becomes unknown', a => { pick(a, sourceMain).valuesByMode['6:2'].id = 'VariableID:UNKNOWN'; }, 'unresolved');
reject('non-first same-key variable has altered codeSyntax', a => { a.variables.filter(x => x.key === baseMain)[1].codeSyntax.WEB = 'wrong'; });
reject('a hidden remote same-key handle cannot be masked by local sibling', a => { const v = a.variables.filter(x => x.key === baseMain)[0]; v.remote = true; v.hiddenFromPublishing = true; }, 'locality');
reject('remote same-key collection cannot be masked by local sibling', a => { const c = a.collections.filter(x => x.key === baseColor)[1]; c.remote = true; c.hiddenFromPublishing = true; }, 'locality');
reject('17 remote Badge main handles still fail even with local same-key main elsewhere', a => { for (const n of a.nodes) if (n.main?.id === '4018:3') n.main.remote = true; }, 'locality');
reject('wrong main key cannot be hidden by same geometry', a => { a.nodes.find(n => n.main).main.key = 'different-component-key'; });
reject('same-locality hidden metadata change fails', a => { const v = a.variables.find(x => x.remote); v.hiddenFromPublishing = false; });
reject('missing hidden metadata is not normalized away', a => { delete a.variables[0].hiddenFromPublishing; });
reject('unexpected same-value hidden transport fails', a => { a.variables.find(x => x.remote).hiddenFromPublishing = false; });
reject('resolved Light changed to Dark', a => { const c = a.collections.find(x => x.key === baseColor); a.nodes[0].properties.resolvedVariableModes[c.id] = '6:3'; });
reject('same-key collection handles resolving conflicting Light/Dark fail', a => {
  const cs = a.collections.filter(x => x.key === baseColor);
  a.nodes[0].properties.resolvedVariableModes[cs[0].id] = '6:2'; a.nodes[0].properties.resolvedVariableModes[cs[1].id] = '6:3';
});
reject('explicit Light added although current effective mode is Light', a => { const c = a.collections.find(x => x.key === baseColor); a.nodes[0].properties.explicitVariableModes[c.id] = '6:2'; });
reject('conflicting explicit aliases fail', a => { const cs = a.collections.filter(x => x.key === baseColor); a.nodes[0].properties.explicitVariableModes = { [cs[0].id]: '6:2', [cs[1].id]: '6:3' }; });
for (const value of [null, false, 0, []]) reject('malformed explicit mode object ' + JSON.stringify(value), a => { a.nodes[0].properties.explicitVariableModes = value; }, 'unresolved');
reject('malformed resolved mode object', a => { a.nodes[0].properties.resolvedVariableModes = null; }, 'unresolved');
reject('default mode changes', a => { a.collections.find(x => x.key === baseColor).defaultModeId = '6:3'; });
reject('collection mode order changes', a => { a.collections.find(x => x.key === baseColor).modes.reverse(); });
reject('duplicate collection mode name fails', a => { const c = a.collections.find(x => x.key === baseColor); c.modes[1].name = c.modes[0].name; }, 'unresolved');
reject('duplicate collection mode ID fails', a => { const c = a.collections.find(x => x.key === baseColor); c.modes[1].modeId = c.modes[0].modeId; }, 'unresolved');
reject('non-first same-key style has altered font size', a => { a.styles.filter(x => x.name === 'Badge')[1].fontSize += 1; });
reject('style font variation changes', a => { a.styles.find(x => x.name === 'Badge').fontName.variationSettings.wght += 100; });
reject('live text font changes independently of style', a => { a.nodes.find(x => x.text).text.fontSize += 1; });
reject('live text characters change', a => { a.nodes.find(x => x.text).text.characters += '!'; });
reject('existing override removed', a => { a.nodes.find(x => x.componentProperties?.overrides?.length).componentProperties.overrides.pop(); });
reject('new override inserted', a => { a.nodes.find(x => x.componentProperties?.overrides?.length).componentProperties.overrides[0].overriddenFields.push('textStyleId'); });
reject('hidden descendant becomes visible', a => { a.nodes.find(x => x.geometry.visible === false).geometry.visible = true; });
reject('descendant geometry changes', a => { a.nodes[1].geometry.width += 2; });
reject('unknown bound variable ID is unresolved', a => { a.nodes[0].properties.fills[0].boundVariables.color.id = 'VariableID:UNKNOWN'; }, 'unresolved');
reject('unknown INSTANCE_SWAP ID is unresolved', a => { const n = a.nodes.find(x => x.componentProperties); n.componentProperties.componentProperties['test'] = { type: 'INSTANCE_SWAP', value: '999:unknown' }; }, 'unresolved');
reject('duplicate exact asset ID fails', a => { a.variables[1].id = a.variables[0].id; }, 'unresolved');
reject('unknown boolean locality fails', a => { a.variables[0].remote = null; }, 'unresolved');
for (const name of inputNames) assert.equal(hash(name), hashes[name], 'Captured input changed: ' + name);
process.stdout.write(JSON.stringify({ ok: true, fixtureOnly: true, liveCaptureStillFails: true, tests: results.length, passed: results.length, inputSha256: hashes, results }, null, 2) + '\n');
