/** One-time E4 P2.c native COPY comparison. No Figma/input writes.
 * CLI: node e4-compare-reference-copy.mjs BEFORE AFTER APPROVALS
 * Inputs retain the assembled sample-audit bundle format.
 * APPROVALS: sourceFileKey,destinationFileKey,sourcePageId,destinationPageId,
 * sourceRootId,destinationRootId,localComponentKeys,localVariableKeys,
 * localCollectionKeys,localStyleKeys,externalNodePairs?:[{sourceId,destinationId}].
 * Native MOVE extension: roots:[{sourceId,destinationId}] instead of singular roots;
 * componentPairs:[{sourceId,sourceKey,destinationId,destinationKey}] explicitly
 * approves observed component/variant key migration. Optional foundationProof is the
 * captured native-duplicate proof (diffs:[], source/destinationFileKey, maps).
 * Without that explicit proof, all foundation keys must remain unchanged.
 * allowRootTranslation:false also checks root x/y/transform exactly for rebind-only.
 * Same-key representations remain separate (key,remote,id) observations.
 * Semantic equality never waives expected locality. Root translation only.
 */
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const own = (v, k) => Object.prototype.hasOwnProperty.call(v, k);
const styleFields = new Set(['textStyleId', 'fillStyleId', 'strokeStyleId', 'effectStyleId', 'gridStyleId']);
const ordered = v => Array.isArray(v) ? v.map(ordered) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).sort(([a], [b]) => a.localeCompare(b)).map(([k, x]) => [k, ordered(x)])) : v;
const rawEqual = (a, b) => JSON.stringify(ordered(a)) === JSON.stringify(ordered(b));
const handle = x => ({ key: x.key, remote: x.remote, id: x.id });

export function compareReferenceCopy({ before, after, approvals: a }) {
  const diffs = [], unresolved = [], representationChanges = [];
  const mappings = { nodes: [], mains: [], assets: [], bindings: [], translations: [] };
  const rootPairs = a?.roots || [{ sourceId: a?.sourceRootId, destinationId: a?.destinationRootId }];
  const rootDestinations = new Map(rootPairs.map(x => [x.sourceId, x.destinationId]));
  mappings.roots = rootPairs;
  const absent = x => x === undefined ? { absent: true } : x;
  function fail(at, expected, actual, code = 'VALUE_CHANGED', category = 'semantic') { diffs.push({ at, code, category, expected: absent(expected), actual: absent(actual) }); }
  function need(ok, at, detail) { if (!ok) unresolved.push({ at, detail }); return !!ok; }
  function eq(x, y, at) {
    if (typeof x === 'number' && typeof y === 'number') { if (!Number.isFinite(x) || !Number.isFinite(y) || Math.abs(x - y) > 1e-6) fail(at, x, y); return; }
    if (x === y) return;
    if (!x || !y || typeof x !== 'object' || typeof y !== 'object' || Array.isArray(x) !== Array.isArray(y)) { fail(at, x, y); return; }
    if (Array.isArray(x)) { eq(x.length, y.length, at + '/length'); for (let i = 0; i < Math.min(x.length, y.length); i++) eq(x[i], y[i], at + '/' + i); return; }
    for (const k of [...new Set([...Object.keys(x), ...Object.keys(y)])].sort()) {
      if (!own(x, k) || !own(y, k)) fail(at + '/' + k, x[k], y[k], 'FIELD_CHANGED'); else eq(x[k], y[k], at + '/' + k);
    }
  }
  function representation(category, at, x, y, extra = {}) {
    if (!rawEqual(x, y)) representationChanges.push({ category, at, before: absent(x), after: absent(y), ...extra });
  }
  function uniqueId(rows, at) {
    const map = new Map();
    for (const row of rows) {
      if (!need(row && typeof row.id === 'string' && row.id, at, 'Missing exact ID')) continue;
      if (!need(!map.has(row.id), at + '/' + row.id, 'Duplicate ID')) continue;
      map.set(row.id, row);
    }
    return map;
  }
  function bundle(b, side) {
    if (!need(b && b.summary && Array.isArray(b.nodes), side, 'Need one assembled probe bundle')) return null;
    for (const part of ['nodes', 'variables', 'collections', 'styles', 'references']) if (!need(Array.isArray(b[part]), side + '/' + part, 'Missing complete part')) return null;
    eq([], b.summary.errors, side + '/errors'); eq([], b.summary.createdNodeIds, side + '/createdNodeIds'); eq([], b.summary.mutatedNodeIds, side + '/mutatedNodeIds');
    for (const kind of ['nodes', 'variables', 'collections', 'styles']) eq(b.summary.counts[kind], b[kind].length, side + '/complete/' + kind);
    eq(b.summary.counts.instances, b.nodes.filter(n => n.type === 'INSTANCE').length, side + '/instances');
    eq(b.summary.counts.text, b.nodes.filter(n => n.type === 'TEXT').length, side + '/text');
    eq(b.summary.counts.reactions, b.nodes.reduce((s, n) => s + (n.properties.reactions || []).length, 0), side + '/reactions');
    eq(side === 'before' ? a.sourceFileKey : a.destinationFileKey, b.summary.fileKey, side + '/fileKey');
    eq(side === 'before' ? a.sourcePageId : a.destinationPageId, b.summary.pageId, side + '/pageId');
    eq(rootPairs.map(x => side === 'before' ? x.sourceId : x.destinationId), b.summary.roots.map(x => x.id), side + '/roots');
    return b;
  }
  if (!need(a, 'approvals', 'Missing file/page/root/locality approvals')) return { ok: false, diffs, unresolved, representationChanges, mappings };
  for (const k of ['sourceFileKey', 'destinationFileKey', 'sourcePageId', 'destinationPageId']) need(typeof a[k] === 'string' && a[k], 'approvals/' + k, 'Missing identity');
  need(rootPairs.length > 0 && rootPairs.every(x => typeof x.sourceId === 'string' && x.sourceId && typeof x.destinationId === 'string' && x.destinationId), 'approvals/roots', 'Missing exact root pairs');
  need(rootDestinations.size === rootPairs.length && new Set(rootPairs.map(x => x.destinationId)).size === rootPairs.length, 'approvals/roots', 'Root mapping must be injective');
  for (const k of ['localComponentKeys', 'localVariableKeys', 'localCollectionKeys', 'localStyleKeys']) need(Array.isArray(a[k]) && a[k].every(x => typeof x === 'string' && x), 'approvals/' + k, 'Need explicit local-key list');
  if (unresolved.length) return { ok: false, diffs, unresolved, representationChanges, mappings };
  const left = bundle(before, 'before'), right = bundle(after, 'after');
  if (!left || !right) return { ok: false, diffs, unresolved, representationChanges, mappings };
  const nodeMaps = { before: uniqueId(left.nodes, 'before/nodes'), after: uniqueId(right.nodes, 'after/nodes') };
  const locals = { mains: new Set(a.localComponentKeys), variables: new Set(a.localVariableKeys), collections: new Set(a.localCollectionKeys), styles: new Set(a.localStyleKeys) };
  const foundationKeys = { variables: new Map(), collections: new Map(), styles: new Map() };
  if (a.foundationProof) {
    const proof = a.foundationProof;
    eq([], proof.diffs, 'foundationProof/diffs');
    eq(a.destinationFileKey, proof.destinationFileKey, 'foundationProof/destinationFileKey');
    need(typeof proof.sourceFileKey === 'string' && proof.sourceFileKey && proof.sourceFileKey !== proof.destinationFileKey, 'foundationProof/sourceFileKey', 'Need distinct source file identity');
    need([proof.sourceFileKey, proof.destinationFileKey].includes(a.sourceFileKey), 'foundationProof/sourceFileKey', 'Before capture must belong to the approved source or moved destination');
    for (const [kind, groups] of [['variables', ['variables']], ['collections', ['collections']], ['styles', ['textStyles', 'effectStyles']]]) {
      const targets = new Set();
      for (const group of groups) {
        if (!need(Array.isArray(proof.maps?.[group]), 'foundationProof/' + group, 'Missing captured mapping group')) continue;
        for (const pair of proof.maps[group]) {
          const from = pair.source, to = pair.destination;
          if (!need(from && to && [from.id, from.key, to.id, to.key].every(x => typeof x === 'string' && x) && from.key !== to.key, 'foundationProof/' + group, 'Need exact native-copy identities')) continue;
          need(!foundationKeys[kind].has(from.key) && !targets.has(to.key), 'foundationProof/' + group, 'Mapping must be injective');
          need(locals[kind].has(to.key), 'foundationProof/' + group, 'Mapped destination must be approved local');
          foundationKeys[kind].set(from.key, to.key); targets.add(to.key);
        }
      }
      for (const key of targets) need(!foundationKeys[kind].has(key), 'foundationProof/' + kind, 'No chained/cyclic identity mappings');
    }
    mappings.foundationPairs = Object.fromEntries(Object.entries(foundationKeys).map(([kind, keys]) => [kind, [...keys].map(([sourceKey, destinationKey]) => ({ sourceKey, destinationKey }))]));
  }
  const assetKey = (kind, key, side) => side === 'before' ? foundationKeys[kind].get(key) || key : key;
  const assets = { before: {}, after: {} }, mains = { before: new Map(), after: new Map() }, refs = { before: new Map(), after: new Map() };
  for (const [side, b] of [['before', left], ['after', right]]) {
    for (const kind of ['variables', 'collections', 'styles']) {
      const byId = uniqueId(b[kind], side + '/' + kind), byKey = new Map();
      for (const item of byId.values()) {
        if (!need(typeof item.key === 'string' && item.key && typeof item.remote === 'boolean', side + '/' + kind + '/' + item.id, 'Missing key/boolean locality')) continue;
        const logicalKey = assetKey(kind, item.key, side);
        byKey.set(logicalKey, [...(byKey.get(logicalKey) || []), item]);
        if (side === 'after' && item.remote !== !locals[kind].has(item.key)) fail(kind + '/' + item.id + '/remote', !locals[kind].has(item.key), item.remote, 'LOCALITY_MISMATCH', 'locality');
        if (kind === 'collections') {
          const names = new Set(), ids = new Set();
          for (const mode of item.modes || []) {
            need(typeof mode.modeId === 'string' && typeof mode.name === 'string', side + '/' + item.id, 'Invalid mode identity');
            need(!names.has(mode.name) && !ids.has(mode.modeId), side + '/' + item.id, 'Duplicate mode name/ID'); names.add(mode.name); ids.add(mode.modeId);
          }
          need(ids.has(item.defaultModeId), side + '/' + item.id, 'Unknown default mode');
        }
      }
      assets[side][kind] = { byId, byKey };
    }
    for (const n of b.nodes) if (n.type === 'INSTANCE') {
      if (!need(n.main && typeof n.main.id === 'string' && typeof n.main.key === 'string' && n.main.key && typeof n.main.remote === 'boolean', side + '/main/' + n.id, 'Broken or incomplete main')) continue;
      if (mains[side].has(n.main.id)) eq(mains[side].get(n.main.id), n.main, side + '/mainIdentity/' + n.main.id); else mains[side].set(n.main.id, n.main);
    }
  }
  const nodeIds = new Map(), paths = new Map(), sourcePaths = new Set(), external = new Map();
  for (const pair of a.externalNodePairs || []) {
    need(!external.has(pair.sourceId), 'external', 'Duplicate external node mapping'); external.set(pair.sourceId, pair.destinationId);
  }
  for (const n of right.nodes) { const p = n.rootId + '|' + JSON.stringify(n.path); need(!paths.has(p), 'after/path/' + p, 'Duplicate child path'); paths.set(p, n); need(rootPairs.some(x => x.destinationId === n.rootId), 'after/root/' + n.id, 'Unapproved root'); }
  eq(left.nodes.length, right.nodes.length, 'nodeCount');
  for (const n of left.nodes) {
    const p = n.rootId + '|' + JSON.stringify(n.path); need(!sourcePaths.has(p), 'before/path/' + p, 'Duplicate child path'); sourcePaths.add(p); need(rootDestinations.has(n.rootId), 'before/root/' + n.id, 'Unapproved root');
    const now = paths.get(rootDestinations.get(n.rootId) + '|' + JSON.stringify(n.path)); if (!need(now, 'path/' + p, 'Missing exact child path')) continue;
    eq(n.type, now.type, 'path/' + p + '/type'); eq(n.name, now.name, 'path/' + p + '/name'); eq(n.childIds.length, now.childIds.length, 'path/' + p + '/children');
    nodeIds.set(n.id, now.id); mappings.nodes.push({ sourceId: n.id, destinationId: now.id, sourceRootId: n.rootId, destinationRootId: now.rootId, path: n.path });
  }
  for (const pair of rootPairs) eq(pair.destinationId, nodeIds.get(pair.sourceId), 'rootMapping/' + pair.sourceId);
  eq(nodeIds.size, new Set(nodeIds.values()).size, 'nodeMappingInjective');
  const componentKeys = new Map(), componentTargets = new Set();
  for (const pair of a.componentPairs || []) {
    const old = nodeMaps.before.get(pair.sourceId), now = nodeMaps.after.get(pair.destinationId);
    if (!need(old && now && ['COMPONENT', 'COMPONENT_SET'].includes(old.type) && old.type === now.type && nodeIds.get(old.id) === now.id && old.key === pair.sourceKey && now.key === pair.destinationKey, 'componentPair', 'Component mapping must match observed exact root/path/type/keys')) continue;
    need(!componentKeys.has(pair.sourceKey) && !componentTargets.has(pair.destinationKey), 'componentPair', 'Component mapping must be injective');
    componentKeys.set(pair.sourceKey, pair.destinationKey); componentTargets.add(pair.destinationKey);
  }
  mappings.componentPairs = a.componentPairs || [];
  function nodeId(id, side, at) {
    if (id === null || id === '') return id;
    if (side === 'after') return id;
    const mapped = nodeIds.get(id) || external.get(id);
    need(mapped, at, 'Unknown external node identity: ' + id); return mapped || id;
  }
  function asset(kind, id, side, at, record = false) {
    if (id === '' || id === null || id === '__FIGMA_MIXED__') return id;
    const item = assets[side][kind].byId.get(id);
    if (!need(item, side + '/' + at, 'Unknown ' + kind + ' ID: ' + id)) return 'UNKNOWN:' + id;
    if (record) refs[side].set(at, { kind, ...handle(item) });
    return assetKey(kind, item.key, side);
  }
  function modeName(collectionId, modeId, side, at) {
    const col = assets[side].collections.byId.get(collectionId), mode = col?.modes.find(x => x.modeId === modeId);
    if (!need(mode, side + '/' + at, 'Unknown mode in exact collection ID')) return 'UNKNOWN:' + modeId;
    return mode.name;
  }
  function modeObject(value, side, at, resolved) {
    if (!need(value !== null && typeof value === 'object' && !Array.isArray(value), side + '/' + at, 'Mode bindings must be a non-null object')) return { invalidModeBindings: value };
    const result = new Map(), entries = [];
    for (const [id, modeId] of Object.entries(value)) {
      const key = asset('collections', id, side, at + '/' + id), name = modeName(id, modeId, side, at);
      entries.push({ key, name }); result.set(key, [...(result.get(key) || []), name]);
    }
    for (const [key, names] of result) if (new Set(names).size > 1) fail(side + '/' + at + '/' + key, 'one semantic mode', names, 'CONFLICTING_MODE_HANDLES');
    if (!resolved) return entries.sort((x, y) => x.key.localeCompare(y.key) || x.name.localeCompare(y.name));
    return [...result].map(([key, names]) => ({ key, names: [...new Set(names)].sort() })).sort((x, y) => x.key.localeCompare(y.key));
  }
  function swapIdentity(value, side, at) {
    if (value === '') return value;
    const byId = mains[side].get(value), byKey = [...mains[side].values()].find(x => x.key === value);
    if (!need(byId || byKey, side + '/' + at, 'Unobserved INSTANCE_SWAP main identity: ' + value)) return 'UNKNOWN:' + value;
    const key = (byId || byKey).key;
    return side === 'before' ? componentKeys.get(key) || key : key;
  }
  function canonical(v, side, at, record = false) {
    if (!v || typeof v !== 'object') return v;
    if (Array.isArray(v)) return v.map((x, i) => canonical(x, side, at + '/' + i, record));
    const out = {};
    for (const [key, x] of Object.entries(v)) {
      const p = at + '/' + key;
      if (v.type === 'VARIABLE_ALIAS' && key === 'id') out[key] = asset('variables', x, side, p, record);
      else if (styleFields.has(key)) out[key] = asset('styles', x, side, p, record);
      else if (key === 'variableId') out[key] = asset('variables', x, side, p, record);
      else if (key === 'variableCollectionId') out[key] = asset('collections', x, side, p, record);
      else if (key === 'variableModeId' && v.variableCollectionId) out[key] = modeName(v.variableCollectionId, x, side, p);
      else if (key === 'resolvedVariableModes' || key === 'explicitVariableModes') out[key] = modeObject(x, side, p, key === 'resolvedVariableModes');
      else if (key === 'destinationId') out[key] = nodeId(x, side, p);
      else if (v.type === 'INSTANCE_SWAP' && (key === 'value' || key === 'defaultValue')) out[key] = swapIdentity(x, side, p);
      else out[key] = canonical(x, side, p, record);
    }
    return out;
  }
  function semanticAsset(item, kind, side) {
    const out = canonical(item, side, kind + '/' + item.id);
    delete out.id; delete out.remote; delete out.hiddenFromPublishing;
    out.key = assetKey(kind, item.key, side);
    if (kind === 'collections') {
      out.defaultModeId = modeName(item.id, item.defaultModeId, side, 'defaultMode');
      out.modes = item.modes.map(m => ({ ...m, modeId: modeName(item.id, m.modeId, side, 'mode') }));
    }
    if (kind === 'variables') out.valuesByMode = Object.fromEntries(Object.entries(item.valuesByMode).map(([id, value]) => [modeName(item.variableCollectionId, id, side, 'variableMode/' + item.id), canonical(value, side, 'variableValue/' + item.id)]));
    return out;
  }
  function hiddenMetadata(old, now, at) {
    const x = old.hiddenFromPublishing, y = now.hiddenFromPublishing;
    const sameField = x === y && own(old, 'hiddenFromPublishing') === own(now, 'hiddenFromPublishing');
    if (sameField && (old.remote === now.remote || (!own(old, 'hiddenFromPublishing') && !own(now, 'hiddenFromPublishing')))) return;
    const allowed = typeof x === 'boolean' && typeof y === 'boolean' && old.remote !== now.remote && x === old.remote && y === now.remote;
    representation('hiddenFromPublishing', at, { ...handle(old), present: own(old, 'hiddenFromPublishing'), value: absent(x) }, { ...handle(now), present: own(now, 'hiddenFromPublishing'), value: absent(y) }, { allowedTransportPattern: allowed });
    if (!allowed) fail(at, x, y, 'HIDDEN_METADATA_CHANGED');
  }
  for (const kind of ['variables', 'collections', 'styles']) {
    const src = assets.before[kind].byKey, dst = assets.after[kind].byKey;
    eq([...src.keys()].sort(), [...dst.keys()].sort(), kind + '/exactSameKeyClosure');
    for (const [key, oldRows] of src) {
      const nowRows = dst.get(key); if (!need(nowRows?.length, kind + '/' + key, 'Missing same-key asset')) continue;
      mappings.assets.push({ kind, key, before: oldRows.map(handle), after: nowRows.map(handle), expectedRemote: !locals[kind].has(key) });
      representation('assetHandles', kind + '/' + key, oldRows.map(handle), nowRows.map(handle));
      const base = semanticAsset(oldRows[0], kind, 'before');
      for (const old of oldRows.slice(1)) eq(base, semanticAsset(old, kind, 'before'), 'before/' + kind + '/' + old.id + '/sameKeyMetadata');
      for (const rows of [oldRows, nowRows]) for (const remote of [false, true]) {
        const sameRole = rows.filter(x => x.remote === remote);
        for (const other of sameRole.slice(1)) hiddenMetadata(sameRole[0], other, kind + '/' + key + '/sameLocalityHidden');
      }
      for (const now of nowRows) {
        eq(base, semanticAsset(now, kind, 'after'), kind + '/' + now.id + '/metadata');
        for (const old of oldRows) hiddenMetadata(old, now, kind + '/' + now.id + '/hiddenFromPublishing');
      }
    }
  }
  for (const old of left.nodes) {
    const now = nodeMaps.after.get(nodeIds.get(old.id)); if (!now) continue;
    const at = (rootPairs.length === 1 ? 'node/path/' : 'node/root/' + rootPairs.findIndex(x => x.sourceId === old.rootId) + '/path/') + (old.path.join('/') || 'root');
    const expected = canonical(old, 'before', at, true), actual = canonical(now, 'after', at, true);
    expected.id = now.id; expected.rootId = rootDestinations.get(old.rootId);
    if (['COMPONENT', 'COMPONENT_SET'].includes(old.type)) expected.key = componentKeys.get(old.key) || old.key;
    expected.parentId = old.path.length === 0 ? a.destinationPageId : nodeId(old.parentId, 'before', at + '/parent');
    expected.childIds = old.childIds.map(id => nodeId(id, 'before', at + '/child'));
    if (old.main && now.main) {
      const expectedKey = componentKeys.get(old.main.key) || old.main.key;
      const expectedRemote = !locals.mains.has(expectedKey);
      mappings.mains.push({ path: old.path, sourceNodeId: old.id, destinationNodeId: now.id, before: handle(old.main), after: handle(now.main), expectedRemote });
      eq(expectedKey, now.main.key, at + '/main/key');
      if (now.main.remote !== expectedRemote) fail(at + '/main/remote', expectedRemote, now.main.remote, 'LOCALITY_MISMATCH', 'locality');
      representation('mainHandle', at + '/main', handle(old.main), handle(now.main));
      // Identity checked at this exact instance path; no global old-main-ID -> one new ID assumption.
      expected.main.id = now.main.id; expected.main.remote = now.main.remote; expected.main.key = expectedKey;
    }
    if (old.componentProperties?.overrides) expected.componentProperties.overrides = old.componentProperties.overrides.map(x => ({ ...x, id: nodeId(x.id, 'before', at + '/override') }));
    if (old.path.length === 0) {
      eq(a.sourcePageId, old.parentId, 'sourceRootParent');
      mappings.translations.push({ before: { x: old.geometry.x, y: old.geometry.y }, after: { x: now.geometry.x, y: now.geometry.y } });
      if (a.allowRootTranslation !== false) {
        expected.geometry.x = now.geometry.x; expected.geometry.y = now.geometry.y;
        if (expected.geometry.relativeTransform && now.geometry.relativeTransform) { expected.geometry.relativeTransform[0][2] = now.geometry.x; expected.geometry.relativeTransform[1][2] = now.geometry.y; }
      }
    }
    for (const f of ['resolvedVariableModes', 'explicitVariableModes']) representation(f, at + '/properties/' + f, old.properties[f], now.properties[f], { semanticBefore: expected.properties[f], semanticAfter: actual.properties[f] });
    eq(expected, actual, at);
  }
  for (const [at, old] of refs.before) {
    const now = refs.after.get(at); if (!need(now, at, 'Missing typed reference at exact path')) continue;
    mappings.bindings.push({ at, before: old, after: now, expectedRemote: !locals[now.kind].has(now.key) });
    representation('bindingHandle', at, old, now);
  }
  eq(1, left.summary.ancestors.length, 'before/directPageAncestor'); eq(1, right.summary.ancestors.length, 'after/directPageAncestor');
  const lp = left.summary.ancestors.find(x => x.id === a.sourcePageId), rp = right.summary.ancestors.find(x => x.id === a.destinationPageId);
  if (need(lp && rp, 'ancestors', 'Need direct page ancestors')) {
    eq(lp.type, rp.type, 'ancestor/type'); eq(canonical(lp.modes, 'before', 'ancestor'), canonical(rp.modes, 'after', 'ancestor'), 'ancestor/modes');
    representation('ancestorModes', 'ancestor/modes', lp.modes, rp.modes);
  }
  function referenceLocation(at, side) {
    const identities = new Map([...nodeMaps[side]].map(([id]) => [id, side === 'before' ? nodeId(id, side, 'reference/at') : id]));
    for (const kind of ['variables', 'collections', 'styles']) for (const item of assets[side][kind].byId.values()) identities.set(item.id, kind + ':' + assetKey(kind, item.key, side));
    const id = [...identities.keys()].sort((x, y) => y.length - x.length).find(id => at === id || at.startsWith(id + '/'));
    return id ? identities.get(id) + at.slice(id.length) : at;
  }
  function referenceRows(rows, side) { return rows.map(ref => {
    const out = { ...ref, at: referenceLocation(ref.at, side) };
    if (ref.kind === 'node') { out.id = nodeId(ref.id, side, 'reference/id'); if (ref.target) out.target = { ...ref.target, id: nodeId(ref.target.id, side, 'reference/target') }; }
    else if (ref.kind === 'variable') out.id = asset('variables', ref.id, side, 'reference/variable');
    else if (ref.kind === 'collection') out.id = asset('collections', ref.id, side, 'reference/collection');
    else need(false, 'reference/' + ref.kind, 'Unknown reference kind');
    return out;
  }); }
  eq(referenceRows(left.references, 'before'), referenceRows(right.references, 'after'), 'references');
  const foreignFoundations = [];
  for (const kind of ['variables', 'styles', 'collections']) for (const item of right[kind]) if (item.remote) foreignFoundations.push({ kind, ...handle(item), name: item.name, expectedRemote: !locals[kind].has(item.key) });
  const foreignUsages = [...refs.after].filter(([, v]) => v.remote).map(([at, v]) => ({ at, ...v, expectedRemote: !locals[v.kind].has(v.key) }));
  const distinctUnresolved = [...new Map(unresolved.map(x => [JSON.stringify(x), x])).values()];
  return { ok: !diffs.length && !distinctUnresolved.length, comparison: a.foundationProof ? 'E4 native migration with explicit captured foundation key mapping, classified representations' : 'E4 same-key native reference COPY or approved component MOVE, classified representations', tolerance: 1e-6,
    counts: { beforeNodes: nodeMaps.before.size, afterNodes: nodeMaps.after.size, mappedNodes: nodeIds.size, instances: mappings.mains.length, diffs: diffs.length, semanticDiffs: diffs.filter(x => x.category === 'semantic').length, localityDiffs: diffs.filter(x => x.category === 'locality').length, unresolved: distinctUnresolved.length, representationChanges: representationChanges.length },
    diffs, unresolved: distinctUnresolved, representationChanges, mappings, foreignFoundations, foreignUsages,
    limits: ['Only captured probe fields, not whole-file proof', a.foundationProof ? 'Foundation key changes use only explicit captured native-duplicate proof; every mapped representation still requires equal metadata' : 'Same-key native copy only; changing foundation keys needs explicit captured native-duplicate proof', 'All asset handles remain subject to approved locality, including collections reached only through resolved modes', 'Hidden changes classify only observed false/local <-> true/remote transport; same-locality or missing-field changes fail', 'Unknown INSTANCE_SWAP IDs fail unresolved; no name/suffix inference', 'Raw resolved-mode representations remain in report; conflicting logical modes fail', 'Foreign usage includes paint/segment mirrors, not setter counts'] };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length !== 5) throw new Error('Usage: node e4-compare-reference-copy.mjs BEFORE AFTER APPROVALS');
    const [before, after, approvals] = process.argv.slice(2).map(p => JSON.parse(readFileSync(p, 'utf8')));
    const result = compareReferenceCopy({ before, after, approvals }); process.stdout.write(JSON.stringify(result, null, 2) + '\n'); process.exitCode = result.ok ? 0 : 1;
  } catch (error) { process.stderr.write(String(error.message).replace(/[\r\n]+/g, ' ') + '\n'); process.exitCode = 2; }
}
