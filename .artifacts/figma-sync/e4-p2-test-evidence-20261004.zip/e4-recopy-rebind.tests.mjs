/** Portable Node-only tests of actual generated dry/apply JS, using captured Figma fixtures.
 * No owner worktree imports, packages, network or Figma calls.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const p = name => new URL('./' + name, import.meta.url);
const read = name => JSON.parse(readFileSync(p(name), 'utf8'));
const hash = value => createHash('sha256').update(value).digest('hex');
const data = read('e4-recopy-after.json'), dryInput = read('e4-recopy-rebind-dry-input.json');
const drySource = readFileSync(p('e4-recopy-rebind-dry.js'), 'utf8'), applySource = readFileSync(p('e4-recopy-rebind-apply.js'), 'utf8');
const plain = v => JSON.parse(JSON.stringify(v));
const rawHash = hash(readFileSync(p('e4-recopy-after.json')));
function decode(envelope) {
  assert.equal(envelope.codec, 'gzip-base64');
  const gzip = Buffer.from(envelope.payload, 'base64'); assert.equal(gzip.length, envelope.gzipBytes);
  const raw = gunzipSync(gzip, { maxOutputLength: envelope.utf8Bytes });
  assert.equal(raw.length, envelope.utf8Bytes); assert.equal(hash(raw), envelope.sha256);
  const result = JSON.parse(raw.toString('utf8'));
  assert.deepEqual(envelope.mutatedNodeIds, result.mutatedNodeIds); return result;
}
function fake(options = {}) {
  const snapshot = structuredClone(data), input = structuredClone(dryInput), map = new Map();
  if (options.mutateCapture) options.mutateCapture(snapshot);
  const variables = new Map([...snapshot.variables, ...input.destinationVariables].map(x => [x.id, x]));
  const collections = new Map([...snapshot.collections, ...input.destinationCollections].map(x => [x.id, x]));
  const styles = new Map([...snapshot.styles, ...input.destinationStyles].map(x => [x.id, x]));
  if (options.mutateTargets) options.mutateTargets({ variables, collections, styles });
  const mutations = [], fonts = [];
  const doc = { id: '0:0', type: 'DOCUMENT', parent: null };
  for (const a of snapshot.summary.ancestors) map.set(a.id, { ...a, ...a.modes, parent: doc });
  for (const row of snapshot.nodes) {
    const n = { id: row.id, name: row.name, type: row.type, ...row.geometry, ...row.properties };
    for (const key of ['key', 'remote', 'componentPropertyDefinitions']) if (Object.hasOwn(row, key)) n[key] = row[key];
    if (row.text) { Object.assign(n, row.text); n.getStyledTextSegments = () => n.segments; }
    if (row.componentProperties) Object.assign(n, row.componentProperties);
    if (row.main) n.getMainComponentAsync = async () => row.main;
    const changed = field => {
      mutations.push({ id: n.id, field });
      if (options.failAfter === mutations.length) throw Error('SIMULATED_MUTATE_THEN_REJECT');
      if (options.unapprovedSideEffect && mutations.length === 1) map.get(options.unapprovedSideEffect).visible = true;
    };
    for (const field of ['fills', 'strokes']) if (field in n) {
      let value = n[field];
      Object.defineProperty(n, field, { configurable: true, enumerable: true, get: () => value, set: v => {
        value = v; n.boundVariables[field] = v.filter(x => x.boundVariables?.color).map(x => plain(x.boundVariables.color));
        if (n.type === 'TEXT' && field === 'fills') for (const segment of n.segments) segment.fills = plain(v);
        changed(field);
      } });
    }
    n.setBoundVariable = (field, variable) => { n.boundVariables[field] = { type: 'VARIABLE_ALIAS', id: variable.id }; changed(field); };
    n.setEffectStyleIdAsync = async id => { n.effectStyleId = id; n.effects = plain(styles.get(id).effects); changed('effectStyleId'); };
    map.set(row.id, n);
  }
  for (const row of snapshot.nodes) { const n = map.get(row.id); n.parent = map.get(row.parentId); n.children = row.childIds.map(id => map.get(id)); }
  for (const a of snapshot.summary.ancestors) map.get(a.id).children = snapshot.summary.roots.map(r => map.get(r.id));
  if (options.noEffectMethod) delete map.get('4029:270').setEffectStyleIdAsync;
  let fontLoads = 0, pageSwitches = 0;
  const figma = { fileKey: snapshot.summary.fileKey, mixed: Symbol('mixed'), skipInvisibleInstanceChildren: true,
    currentPage: options.alreadyOnPage ? map.get(snapshot.summary.pageId) : { id: 'OTHER_PAGE' },
    getNodeByIdAsync: async id => map.get(id) ?? null, setCurrentPageAsync: async page => { pageSwitches++; if (pageSwitches > 1) throw Error('SECOND_PAGE_SWITCH_FORBIDDEN'); figma.currentPage = page; },
    getStyleByIdAsync: async id => styles.get(id) ?? null,
    loadFontAsync: async font => { fonts.push(plain(font)); fontLoads++; if (options.fontFailure) throw Error('FONT_LOAD_FAILED'); if (options.changeWhileLoadingFont && fontLoads === 1) map.get('4029:264').x += 1; },
    variables: { getVariableByIdAsync: async id => variables.get(id) ?? null, getVariableCollectionByIdAsync: async id => collections.get(id) ?? null,
      setBoundVariableForPaint: (paint, field, variable) => ({ ...plain(paint), boundVariables: { ...paint.boundVariables, [field]: { type: 'VARIABLE_ALIAS', id: variable.id } } }) } };
  return { figma, mutations, fonts, map, pageSwitchCount: () => pageSwitches };
}
async function execute(source, options = {}) {
  const fixture = fake(options);
  const context = vm.createContext({ figma: fixture.figma, TextEncoder: undefined, TextDecoder: undefined, Buffer: undefined, Worker: undefined, fetch: undefined });
  const envelope = plain(await new vm.Script('(async()=>{' + source + '})()').runInContext(context, { timeout: 10000 }));
  assert.ok(Buffer.byteLength(JSON.stringify(envelope)) < 19500);
  return { ...fixture, envelope, result: decode(envelope) };
}
const tests = [];
const dry = await execute(drySource);
assert.equal(dry.result.status, 'dry-run-passed', JSON.stringify({ errors: dry.result.errors, budget: dry.result.expectedWorstResultEnvelopeBytes })); assert.equal(dry.mutations.length, 0);
assert.equal(dry.pageSwitchCount(), 1); assert.deepEqual(dry.envelope.createdNodeIds, []);
tests.push({ name: 'generated dry runs all exact preflight and font checks with zero writes', passed: true });
const applied = await execute(applySource);
assert.equal(applied.result.status, 'verified', JSON.stringify(applied.result.errors)); assert.equal(applied.mutations.length, 112);
assert.equal(applied.pageSwitchCount(), 1); assert.ok(applied.result.expectedWorstResultEnvelopeBytes <= 17500); assert.deepEqual(applied.envelope.createdNodeIds, []);
assert.equal(applied.result.trace.length, 112); assert.equal(applied.result.readBack.length, 112); assert.ok(applied.result.readBack.every(x => x.ok));
assert.equal(applied.result.protectedNodes.ok, true); assert.deepEqual(applied.map.get('I4029:265;4023:22').fills, []);
tests.push({ name: 'generated apply changes exactly 112 slots and preserves all protected node fields', passed: true });
const noSwitch = await execute(drySource, { alreadyOnPage: true });
assert.equal(noSwitch.result.status, 'dry-run-passed'); assert.equal(noSwitch.pageSwitchCount(), 0);
tests.push({ name: 'current target page needs zero switches; all other dry/apply paths use at most one', passed: true });
async function blocked(name, options) {
  const run = await execute(applySource, options);
  assert.equal(run.result.status, 'preflight-failed', JSON.stringify(run.result)); assert.equal(run.mutations.length, 0);
  assert.deepEqual(run.result.mutatedNodeIds, []); tests.push({ name, passed: true, errors: run.result.errors });
}
await blocked('snapshot text drift blocks before first write', { mutateCapture: x => { x.nodes.find(n => n.text).text.characters += '!'; } });
await blocked('PAGE explicit mode drift blocks before first write', { mutateCapture: x => { x.summary.ancestors[0].modes.explicitVariableModes['VariableCollectionId:6:4'] = '6:2'; } });
await blocked('empty fills override drift blocks', { mutateCapture: x => { x.nodes.find(n => n.id === 'I4029:265;4023:22').properties.fills = [{ type: 'SOLID' }]; } });
await blocked('destination metadata drift blocks', { mutateTargets: x => { x.variables.get('VariableID:6:70').codeSyntax.WEB = 'wrong'; } });
await blocked('destination key drift blocks', { mutateTargets: x => { x.variables.get('VariableID:6:70').key = 'wrong'; } });
await blocked('remote destination style blocks', { mutateTargets: x => { x.styles.get('S:ac9185935c116643454c30d7a28d3697c6270cbb,').remote = true; } });
await blocked('missing async effect setter blocks before writes', { noEffectMethod: true });
await blocked('font failure blocks before writes', { fontFailure: true });
await blocked('document changes during font load are caught by second full preflight', { changeWhileLoadingFont: true });
const failAt = dryInput.operations.findIndex(o => o.field === 'effectStyleId') + 1;
const interrupted = await execute(applySource, { failAfter: failAt });
assert.equal(interrupted.result.status, 'interrupted'); assert.equal(interrupted.result.unknownMutations, true);
assert.equal(interrupted.result.trace.length, failAt); assert.equal(interrupted.result.trace.at(-1).status, 'threw-possible-mutation');
assert.equal(interrupted.result.readBack.length, 112); assert.ok(interrupted.result.mutatedNodeIds.includes(interrupted.result.inFlight.nodeId));
tests.push({ name: 'async effect setter may mutate then reject: full trace/readback and in-flight ID survive', passed: true });
const sideEffect = await execute(applySource, { unapprovedSideEffect: data.nodes.find(n => n.geometry.visible === false && !dryInput.operations.some(o => o.nodeId === n.id)).id });
assert.equal(sideEffect.result.status, 'interrupted'); assert.ok(sideEffect.result.errors.some(x => x.code === 'PROTECTED_NODE_FIELDS_CHANGED'));
tests.push({ name: 'unapproved hidden descendant side effect fails postcheck', passed: true });
assert.equal(hash(readFileSync(p('e4-recopy-after.json'))), rawHash);
const report = { ok: true, fixtureOnly: true, liveFigmaTested: false, tests: tests.length, results: tests,
  drySourceSha256: hash(drySource), applySourceSha256: hash(applySource), rawSnapshotSha256: rawHash,
  successfulApply: { status: applied.result.status, writes: applied.mutations.length, readBack: applied.result.readBack.length, envelopeBytes: Buffer.byteLength(JSON.stringify(applied.envelope)), preflightWorstExpectedEnvelopeBytes: applied.result.expectedWorstResultEnvelopeBytes, protectedNodes: applied.result.protectedNodes },
  limits: ['Portable fixtures prove generated-code guards and full-field comparison, not live Figma setter behavior', 'A live readonly dry run and root review remain mandatory before apply'] };
writeFileSync(p('e4-recopy-rebind-tests.classified.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
