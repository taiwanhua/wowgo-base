/** One-time TEST reference rebind. Serialized with the unchanged full probe and existing codec. */
export function normalizeSnapshot(snapshot) {
  const copy = JSON.parse(JSON.stringify(snapshot));
  const sort = rows => rows.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  for (const kind of ['variables', 'collections', 'styles']) { sort(copy[kind]); sort(copy.summary[kind]); }
  return copy;
}

export async function runReferenceRebind(figma, input, contract, bytes, codec, capture) {
  const { digest, canonicalJson } = contract;
  const clone = value => JSON.parse(JSON.stringify(value));
  const same = (a, b) => canonicalJson(a) === canonicalJson(b);
  const require = (ok, code) => { if (!ok) throw Error(code); };
  const trace = [], readBack = [], errors = [], attempted = new Set(), completed = new Set();
  const output = { fileKey: input.fileKey, pageId: input.pageId, rootId: input.rootId, apply: input.apply,
    status: 'preflight', operationCount: input.operations.length, trace, readBack, errors, createdNodeIds: [], mutatedNodeIds: [], attemptedNodeIds: [], unknownMutations: false };
  let baseline = null, after = null, inFlight = null, writesStarted = false;
  const liveNodes = new Map(), targets = new Map();
  function caught(phase, error) {
    const detail = String(error.message || error);
    return { phase, code: detail.slice(0, 512), detailSha256: digest(detail), detailBytes: contract.utf8Length(detail), detailShortened: detail.length > 512 };
  }
  function packed(value) {
    const raw = bytes.utf8Encode(canonicalJson(value)), gzip = codec.gzip(raw);
    return { codec: 'gzip-base64', sha256: digest(value), utf8Bytes: raw.length, gzipBytes: gzip.length,
      status: value.status, createdNodeIds: [], mutatedNodeIds: value.mutatedNodeIds, attemptedNodeIds: value.attemptedNodeIds, unknownMutations: value.unknownMutations, payload: bytes.toBase64(gzip) };
  }
  function checkResultBudget() {
    const ids = [...new Set(input.operations.map(o => o.nodeId))];
    const predicted = { ...output, status: 'interrupted', mutatedNodeIds: ids, attemptedNodeIds: ids, unknownMutations: true,
      trace: input.operations.map((o, index) => ({ index, nodeId: o.nodeId, field: o.field, indexInPaints: o.index, destinationKey: o.destination.key, status: 'threw-possible-mutation' })),
      readBack: input.operations.map((o, index) => ({ index, nodeId: o.nodeId, field: o.field, valueDigest: digest({ unique: index, salt: 'different-observed-values' }), asset: { id: o.destination.id, key: o.destination.key, remote: false }, ok: false })),
      errors: Array.from({ length: 5 }, (_, i) => ({ phase: 'after-verification', code: Array.from({ length: 8 }, (_, j) => digest({ i, j, kind: 'diagnostic-budget' })).join(''), detailSha256: digest(i), detailBytes: 100000, detailShortened: true })),
      afterSnapshotDigest: input.expectedSnapshotDigest, afterPartDigests: input.expectedPartDigests,
      protectedNodes: { expectedDigest: input.expectedSnapshotDigest, actualDigest: input.expectedSnapshotDigest, ok: false } };
    const envelopeBytes = contract.utf8Length(JSON.stringify(packed(predicted)));
    output.expectedWorstResultEnvelopeBytes = envelopeBytes;
    // Explicit space for additional actual diagnostics; no mutations if the complete expected trace will not fit.
    require(envelopeBytes <= 17500, 'RESULT_BUDGET_PREFLIGHT_FAILED');
  }
  function parts(snapshot) {
    const out = {};
    for (const key of ['summary', 'nodes', 'variables', 'collections', 'styles', 'references']) out[key] = digest(snapshot[key]);
    return out;
  }
  function metadata(item, expected) {
    const actual = {};
    for (const key of Object.keys(expected)) actual[key] = clone(item[key]);
    require(same(actual, expected), 'DESTINATION_METADATA_DRIFT:' + expected.id);
  }
  function actualField(node, op) {
    if (op.field === 'effectStyleId') return node.effectStyleId;
    if (op.index !== null) return clone(node[op.field][op.index]);
    return clone(node.boundVariables[op.field]);
  }
  function expectedField(op) { return op.field === 'effectStyleId' ? op.source.id : op.index !== null ? op.expectedPaint : op.expectedBinding; }
  function owningInstances(row, snapshotNodes) {
    const chain = [];
    for (let n = row; n; n = snapshotNodes.get(n.parentId)) if (n.type === 'INSTANCE') chain.push(n);
    return chain;
  }
  function assertOwnership(row, op, snapshotNodes) {
    const chain = owningInstances(row, snapshotNodes);
    const holders = chain.filter(n => (n.componentProperties?.overrides || []).some(o => o.id === row.id && o.overriddenFields.includes(op.field))).map(n => n.id);
    if (op.category === 'direct-reference-field') require(chain.length === 0, 'INHERITED_WRITE:' + op.nodeId);
    else require(op.category === 'existing-instance-override' && same(holders, op.existingOverrideHolders) && holders.length > 0, 'OVERRIDE_OWNERSHIP_DRIFT:' + op.nodeId);
  }
  async function fullPreflight() {
    require(figma.fileKey === input.fileKey, 'FILE_KEY_MISMATCH');
    const snapshot = normalizeSnapshot(await capture(figma, input));
    output.observedSnapshotDigest = digest(snapshot); output.observedPartDigests = parts(snapshot);
    require(same(snapshot.summary.errors, []) && same(snapshot.summary.createdNodeIds, []) && same(snapshot.summary.mutatedNodeIds, []), 'PROBE_ERRORS');
    require(output.observedSnapshotDigest === input.expectedSnapshotDigest, 'FULL_SNAPSHOT_DRIFT');
    require(snapshot.nodes.length === 413 && snapshot.summary.counts.instances === 84 && snapshot.summary.roots.length === 1 && snapshot.summary.roots[0].id === input.rootId, 'SCOPE_DRIFT');
    const capturedNodes = new Map(snapshot.nodes.map(n => [n.id, n]));
    const empty = capturedNodes.get(input.preservedEmptyOverride.nodeId);
    require(empty && same(empty.properties.fills, []), 'EMPTY_OVERRIDE_DRIFT');
    for (const op of input.operations) {
      const row = capturedNodes.get(op.nodeId);
      require(row && same(row.path, op.path) && row.type === op.nodeType, 'OPERATION_SCOPE_DRIFT');
      assertOwnership(row, op, capturedNodes);
      const node = await figma.getNodeByIdAsync(op.nodeId);
      require(node && same(actualField(node, op), expectedField(op)), 'OPERATION_FIELD_DRIFT:' + op.nodeId + ':' + op.field);
      if (op.field === 'effectStyleId') require(typeof node.setEffectStyleIdAsync === 'function', 'EFFECT_STYLE_SETTER_UNAVAILABLE');
      else if (op.index === null) require(typeof node.setBoundVariable === 'function', 'VARIABLE_SETTER_UNAVAILABLE');
      else {
        const mirror = row.properties.boundVariables[op.field];
        require(typeof figma.variables.setBoundVariableForPaint === 'function' && row.properties[op.field].length === 1 && Array.isArray(mirror) && mirror.length === 1 && mirror[0].id === op.source.id, 'PAINT_MIRROR_UNSUPPORTED');
      }
      if (node.type === 'TEXT') require(node.textStyleId === '' && node.fillStyleId === '' && node.getStyledTextSegments(['fills', 'fontName', 'textStyleId', 'fillStyleId']).every(s => s.textStyleId === '' && s.fillStyleId === '' && (op.field !== 'fills' || same(s.fills, node.fills))), 'TEXT_SEGMENT_DRIFT');
      liveNodes.set(node.id, node);
    }
    for (const expected of input.destinationVariables) {
      const variable = await figma.variables.getVariableByIdAsync(expected.id);
      require(variable && variable.remote === false && variable.key === expected.key, 'DESTINATION_VARIABLE_IDENTITY');
      metadata(variable, expected); targets.set(expected.id, variable);
    }
    for (const expected of input.destinationCollections) {
      const collection = await figma.variables.getVariableCollectionByIdAsync(expected.id);
      require(collection && collection.remote === false && collection.key === expected.key, 'DESTINATION_COLLECTION_IDENTITY'); metadata(collection, expected);
    }
    for (const expected of input.destinationStyles) {
      const style = await figma.getStyleByIdAsync(expected.id);
      require(style && style.remote === false && style.key === expected.key && style.type === 'EFFECT', 'DESTINATION_STYLE_IDENTITY'); metadata(style, expected); targets.set(expected.id, style);
    }
    for (const op of input.operations) {
      const target = targets.get(op.destination.id);
      require(target && target.key === op.destination.key, 'DESTINATION_NOT_PREFLIGHTED');
      if (op.field !== 'effectStyleId') require(target.resolvedType === op.source.resolvedType, 'VARIABLE_TYPE_DRIFT');
    }
    return snapshot;
  }
  // Preserve every raw node field except the exact approved alias/style slots and their API mirrors.
  function checkProtectedNodes(old, now) {
    const expected = clone(old.nodes), observed = clone(now.nodes);
    const byId = new Map(expected.map(n => [n.id, n]));
    for (const op of input.operations) {
      const n = byId.get(op.nodeId);
      if (op.field === 'effectStyleId') n.properties.effectStyleId = op.destination.id;
      else if (op.index === null) n.properties.boundVariables[op.field].id = op.destination.id;
      else {
        n.properties[op.field][op.index].boundVariables.color.id = op.destination.id;
        // Captured fixtures have one paint per eligible field; keep explicit guards for mirrors.
        const mirror = n.properties.boundVariables[op.field];
        require(Array.isArray(mirror) && mirror.length === 1 && mirror[0].id === op.source.id && n.properties[op.field].length === 1, 'PAINT_MIRROR_UNSUPPORTED');
        mirror[0].id = op.destination.id;
        if (n.text && op.field === 'fills') for (const segment of n.text.segments) {
          require(segment.fills.length === 1 && segment.fills[0].boundVariables.color.id === op.source.id, 'TEXT_MIRROR_UNSUPPORTED');
          segment.fills[0].boundVariables.color.id = op.destination.id;
        }
      }
    }
    function modes(rows, snapshot) {
      const collections = new Map(snapshot.collections.map(c => [c.id, c]));
      for (const row of rows) {
        const resolved = row.properties.resolvedVariableModes, mapped = new Map();
        require(resolved && typeof resolved === 'object' && !Array.isArray(resolved), 'INVALID_RESOLVED_MODES');
        for (const [id, modeId] of Object.entries(resolved)) {
          const collection = collections.get(id), mode = collection?.modes.find(m => m.modeId === modeId);
          require(collection && mode, 'UNKNOWN_RESOLVED_MODE');
          const key = input.collectionKeyPairs[collection.key] || collection.key;
          require(!mapped.has(key) || mapped.get(key) === mode.name, 'CONFLICTING_RESOLVED_MODE'); mapped.set(key, mode.name);
        }
        row.properties.resolvedVariableModes = [...mapped].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0);
      }
    }
    modes(expected, old); modes(observed, now);
    const expectedDigest = digest(expected), actualDigest = digest(observed);
    output.protectedNodes = { expectedDigest, actualDigest, ok: expectedDigest === actualDigest };
    require(expectedDigest === actualDigest, 'PROTECTED_NODE_FIELDS_CHANGED');
    require(same(old.summary.ancestors, now.summary.ancestors), 'PAGE_MODES_CHANGED');
    for (const kind of ['variables', 'collections', 'styles']) {
      const allowed = new Map([...old[kind], ...(kind === 'variables' ? input.destinationVariables : kind === 'collections' ? input.destinationCollections : input.destinationStyles)].map(v => [v.id, v]));
      for (const value of now[kind]) { const prior = allowed.get(value.id); require(prior && same(prior, value), 'POST_ASSET_METADATA_DRIFT:' + value.id); }
    }
  }
  try {
    require(typeof input.apply === 'boolean' && input.operations.length === 112 && input.fileKey === 'aXrbonVJXIMjSz5RTg0Jja' && input.pageId === '44:44' && input.rootId === '4029:264', 'INVALID_OPERATION');
    require(figma.fileKey === input.fileKey, 'FILE_KEY_MISMATCH');
    const page = await figma.getNodeByIdAsync(input.pageId);
    require(page && page.type === 'PAGE', 'PAGE_NOT_FOUND');
    if (figma.currentPage.id !== page.id) await figma.setCurrentPageAsync(page);
    baseline = await fullPreflight();
    output.baselineSnapshotDigest = digest(baseline);
    for (const font of input.fontNames) await figma.loadFontAsync(font);
    // Font loading is async: recapture and repeat every guard immediately before mutations.
    baseline = await fullPreflight();
    checkResultBudget();
    if (!input.apply) output.status = 'dry-run-passed';
    else {
      writesStarted = true;
      for (let index = 0; index < input.operations.length; index++) {
        const op = input.operations[index], node = liveNodes.get(op.nodeId), target = targets.get(op.destination.id);
        require(same(actualField(node, op), expectedField(op)), 'FIELD_DRIFT_BEFORE_SETTER');
        inFlight = { index, nodeId: op.nodeId, field: op.field, indexInPaints: op.index, destinationKey: op.destination.key, status: 'attempted' };
        trace.push(inFlight); attempted.add(node.id);
        if (op.field === 'effectStyleId') await node.setEffectStyleIdAsync(target.id);
        else if (op.index !== null) { const paints = clone(node[op.field]); paints[op.index] = figma.variables.setBoundVariableForPaint(paints[op.index], 'color', target); node[op.field] = paints; }
        else node.setBoundVariable(op.field, target);
        inFlight.status = 'completed'; completed.add(node.id); inFlight = null;
      }
      output.status = 'setters-completed-awaiting-full-verification';
    }
  } catch (error) {
    errors.push(caught(writesStarted ? 'write' : 'preflight', error));
    if (inFlight) { inFlight.status = 'threw-possible-mutation'; output.unknownMutations = true; }
    output.status = writesStarted ? 'interrupted' : 'preflight-failed';
  }
  if (writesStarted) {
    for (let index = 0; index < input.operations.length; index++) {
      const op = input.operations[index];
      try {
        const node = await figma.getNodeByIdAsync(op.nodeId), value = actualField(node, op);
        const id = op.field === 'effectStyleId' ? value : op.index === null ? value.id : value.boundVariables.color.id;
        const asset = op.field === 'effectStyleId' ? await figma.getStyleByIdAsync(id) : await figma.variables.getVariableByIdAsync(id);
        readBack.push({ index, nodeId: op.nodeId, field: op.field, valueDigest: digest(value), asset: asset ? { id: asset.id, key: asset.key, remote: asset.remote } : null, ok: !!asset && asset.id === op.destination.id && asset.key === op.destination.key && !asset.remote });
      } catch (error) { readBack.push({ index, nodeId: op.nodeId, field: op.field, ok: false, error: caught('readback', error) }); output.unknownMutations = true; }
    }
    try {
      after = normalizeSnapshot(await capture(figma, input));
      output.afterSnapshotDigest = digest(after); output.afterPartDigests = parts(after);
      require(same(after.summary.errors, []), 'AFTER_PROBE_ERRORS');
      if (!errors.length && readBack.every(x => x.ok)) { checkProtectedNodes(baseline, after); output.status = 'verified'; }
      else output.status = 'interrupted';
    } catch (error) { errors.push(caught('after-verification', error)); output.status = 'interrupted'; output.unknownMutations = true; }
  }
  output.attemptedNodeIds = [...attempted];
  // Include the in-flight node conservatively: a setter can mutate then reject.
  output.mutatedNodeIds = [...new Set([...completed, ...(inFlight ? [inFlight.nodeId] : [])])];
  output.inFlight = inFlight;
  const envelope = packed(output);
  // Expected full trace/readback capacity was checked before writing. Never return a known oversized envelope.
  if (contract.utf8Length(JSON.stringify(envelope)) > 19500) {
    const recovery = { status: 'interrupted-result-overflow-do-not-retry', trace, readBack,
      createdNodeIds: [], mutatedNodeIds: output.mutatedNodeIds, attemptedNodeIds: output.attemptedNodeIds, unknownMutations: true,
      originalResultDigest: digest(output), errors: [{ code: 'UNEXPECTED_RESULT_OVERFLOW', omittedDiagnosticsOnly: true }] };
    const recovered = packed(recovery);
    require(contract.utf8Length(JSON.stringify(recovered)) <= 19500, 'UNEXPECTED_TRACE_OVERFLOW_DO_NOT_RETRY');
    return recovered;
  }
  return envelope;
}
