/** Portable verification of actual gzip envelopes against the assembled raw captures. */
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const p = name => new URL('./' + name, import.meta.url);
const read = name => JSON.parse(readFileSync(p(name), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const before = read('e4-recopy-before.json'), after = read('e4-recopy-after.json');
const results = [];
function decode(name) {
  const rawFile = readFileSync(p(name)), envelope = JSON.parse(rawFile);
  assert.equal(envelope.codec, 'gzip-base64');
  const gzip = Buffer.from(envelope.payload, 'base64'); assert.equal(gzip.length, envelope.gzipBytes);
  assert.ok(envelope.utf8Bytes < 8 * 1024 * 1024);
  const raw = gunzipSync(gzip, { maxOutputLength: envelope.utf8Bytes });
  assert.equal(raw.length, envelope.utf8Bytes); assert.equal(hash(raw), envelope.sha256);
  results.push({ name, sha256: hash(rawFile), rawBytes: raw.length, gzipBytes: gzip.length, passed: true });
  return JSON.parse(raw.toString('utf8'));
}
const pieces = [0, 100, 200, 250, 350].map(start => decode('e4-recopy-after-' + start + '-envelope.json'));
let at = 0;
for (const chunk of pieces) {
  assert.equal(chunk.start, at); assert.equal(chunk.total, 413); assert.deepEqual(chunk.errors, []);
  assert.deepEqual(chunk.items, after.nodes.slice(at, at + chunk.items.length));
  at += chunk.items.length; assert.equal(chunk.nextStart, at === 413 ? null : at);
}
assert.equal(at, 413);
const tail = decode('e4-recopy-fast-tail-envelope.json');
assert.equal(tail.start, 310); assert.equal(tail.total, 413); assert.equal(tail.nextStart, null);
assert.deepEqual(tail.items, before.nodes.slice(310));
function checkAssets(name, capture) {
  const value = decode(name), sort = rows => [...rows].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const summary = structuredClone(value.summary), expected = structuredClone(capture.summary);
  for (const kind of ['variables', 'collections', 'styles']) {
    assert.deepEqual(sort(value[kind]), sort(capture[kind]));
    summary[kind] = sort(summary[kind]); expected[kind] = sort(expected[kind]);
  }
  assert.deepEqual(summary, expected); assert.deepEqual(value.references, capture.references);
}
checkAssets('e4-recopy-fast-assets-envelope.json', before);
checkAssets('e4-recopy-after-assets-envelope.json', after);
const final = read('e4-recopy-final.json');
let finalAt = 0;
for (const start of [0, 100, 200, 300, 400]) {
  const chunk = decode('e4-recopy-final-' + start + '-envelope.json');
  assert.equal(chunk.start, finalAt); assert.equal(chunk.total, 413); assert.deepEqual(chunk.errors, []);
  assert.deepEqual(chunk.createdNodeIds, []); assert.deepEqual(chunk.mutatedNodeIds, []);
  assert.deepEqual(chunk.items, final.nodes.slice(finalAt, finalAt + chunk.items.length));
  finalAt += chunk.items.length; assert.equal(chunk.nextStart, finalAt === 413 ? null : finalAt);
}
assert.equal(finalAt, 413);
checkAssets('e4-recopy-final-assets-envelope.json', final);
const report = { ok: true, actualCapturedEnvelopes: true, tests: results.length, results, decodedAfterNodes: at, decodedBeforeTailNodes: tail.items.length, decodedFinalNodes: finalAt };
writeFileSync(p('e4-evidence-transport-tests.classified.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
