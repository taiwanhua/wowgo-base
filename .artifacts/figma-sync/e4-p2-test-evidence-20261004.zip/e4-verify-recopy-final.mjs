/** Portable one-time evidence verifier. No Figma, packages, network, or local owner imports. */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
import { normalizeSnapshot } from './e4-recopy-rebind-runtime.mjs';
export const p = name => new URL('./' + name, import.meta.url);
export const read = name => JSON.parse(readFileSync(p(name), 'utf8'));
export const sha = raw => createHash('sha256').update(raw).digest('hex');
export const canonical = x => JSON.stringify(order(x));
function order(x) { return Array.isArray(x) ? x.map(order) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, order(x[k])])) : x; }
export const digest = value => sha(canonical(value));
const clone = structuredClone;
const sorted = ids => [...ids].sort();
function field(row, op) { return op.field === 'effectStyleId' ? row.properties.effectStyleId : op.index === null ? row.properties.boundVariables[op.field] : row.properties[op.field][op.index]; }
function walk(value, visit) { if (!value || typeof value !== 'object') return; visit(value); for (const child of Object.values(value)) walk(child, visit); }

export function loadEvidence() {
  return Object.fromEntries(Object.entries({ before: 'e4-recopy-after.json', after: 'e4-recopy-final.json',
    input: 'e4-recopy-rebind-apply-input.json', manifest: 'e4-recopy-rebind-manifest.json', proof: 'e4-test-foundations-proof.json',
    apply: 'e4-recopy-rebind-apply-result.json', dry: 'e4-recopy-rebind-dry-result.json',
    applyEnvelope: 'e4-recopy-rebind-apply-envelope.json', dryEnvelope: 'e4-recopy-rebind-dry-envelope.json',
    translation: 'e4-recopy-display-translation.json' }).map(([key, name]) => [key, read(name)]));
}

export function verifyFinal(evidence) {
  const { before, after, input, manifest, proof, apply, dry, applyEnvelope, dryEnvelope, translation } = evidence;
  const differences = [], representations = [], checks = [];
  const check = (ok, code, detail = null) => { if (!ok) differences.push({ code, detail }); return ok; };
  const eq = (actual, expected, code) => check(canonical(actual) === canonical(expected), code, canonical(actual) === canonical(expected) ? null : { expected, actual });
  const old = new Map(before.nodes.map(n => [n.id, n])), now = new Map(after.nodes.map(n => [n.id, n]));
  const targets = { variables: input.destinationVariables, collections: input.destinationCollections, styles: input.destinationStyles };
  eq(proof.diffs, [], 'FOUNDATION_PROOF_DIFFS');
  eq(input.fileKey, 'aXrbonVJXIMjSz5RTg0Jja', 'TEST_FILE'); eq(input.pageId, '44:44', 'TEST_PAGE'); eq(input.rootId, '4029:264', 'TEST_ROOT');
  eq(input.operations.length, 112, 'EXACT_OPERATION_COUNT'); eq(manifest.inheritedPreserved.length, 129, 'EXACT_INHERITED_COUNT');
  const collectionPairs = Object.fromEntries(proof.maps.collections.map(m => [m.source.key, m.destination.key]));
  eq(input.collectionKeyPairs, collectionPairs, 'APPROVED_COLLECTION_MAP');
  eq(digest(normalizeSnapshot(before)), input.expectedSnapshotDigest, 'BASELINE_SNAPSHOT_DIGEST');
  eq(before.nodes.length, 413, 'BASELINE_NODES'); eq(after.nodes.length, 413, 'AFTER_NODES');
  eq(after.summary.errors, [], 'AFTER_CAPTURE_ERRORS'); eq(after.summary.createdNodeIds, [], 'AFTER_CAPTURE_CREATED'); eq(after.summary.mutatedNodeIds, [], 'AFTER_CAPTURE_READONLY');
  eq(after.summary.ancestors, before.summary.ancestors, 'PAGE_ANCESTORS_AND_MODES'); eq(after.references, before.references, 'REFERENCES_EXACT');

  // Approval remains per slot: never rewrite all source IDs by key.
  const expected = clone(before.nodes), expectedMap = new Map(expected.map(n => [n.id, n]));
  const slots = new Set();
  for (const [index, op] of input.operations.entries()) {
    const scope = `${op.nodeId}:${op.field}:${op.index}`;
    check(!slots.has(scope), 'DUPLICATE_APPROVED_SLOT', scope); slots.add(scope);
    const row = old.get(op.nodeId), observed = now.get(op.nodeId), exp = expectedMap.get(op.nodeId);
    if (!check(!!row && !!observed, 'MISSING_APPROVED_NODE', op.nodeId)) continue;
    eq(op.path, row.path, 'APPROVED_PATH:' + index); eq(op.nodeType, row.type, 'APPROVED_NODE_TYPE:' + index);
    const approved = manifest.operations[index];
    eq(Object.fromEntries(Object.keys(op).map(k => [k, k === 'index' && op.field === 'effectStyleId' ? approved[k] ?? null : approved[k]])), op, 'FROZEN_MANIFEST_OPERATION:' + index);
    const identityMap = op.field === 'effectStyleId' ? proof.maps.effectStyles : proof.maps.variables;
    const pair = identityMap.find(m => m.source.key === op.source.key);
    check(pair && pair.destination.key === op.destination.key && pair.destination.id === op.destination.id, 'EXACT_FOUNDATION_IDENTITY:' + index);
    const chain = []; for (let n = row; n; n = old.get(n.parentId)) if (n.type === 'INSTANCE') chain.push(n);
    const holders = chain.filter(n => (n.componentProperties?.overrides || []).some(o => o.id === row.id && o.overriddenFields.includes(op.field))).map(n => n.id);
    if (op.category === 'direct-reference-field') eq(chain.length, 0, 'DIRECT_OWNERSHIP:' + index);
    else { eq(op.category, 'existing-instance-override', 'OVERRIDE_CATEGORY:' + index); check(holders.length > 0, 'OVERRIDE_EXISTS:' + index); eq(holders, op.existingOverrideHolders, 'OVERRIDE_HOLDERS:' + index); }
    eq(field(row, op), op.field === 'effectStyleId' ? op.source.id : op.index === null ? op.expectedBinding : op.expectedPaint, 'SOURCE_SLOT:' + index);
    if (op.field === 'effectStyleId') exp.properties.effectStyleId = op.destination.id;
    else if (op.index === null) exp.properties.boundVariables[op.field].id = op.destination.id;
    else {
      eq(exp.properties[op.field].length, 1, 'PAINT_COUNT:' + index);
      eq(exp.properties.boundVariables[op.field], [{ type: 'VARIABLE_ALIAS', id: op.source.id }], 'PAINT_MIRROR:' + index);
      exp.properties[op.field][op.index].boundVariables.color.id = op.destination.id;
      exp.properties.boundVariables[op.field][0].id = op.destination.id;
      if (exp.text && op.field === 'fills') for (const segment of exp.text.segments) {
        eq(segment.fills, row.properties.fills, 'TEXT_PAINT_MIRROR:' + index);
        segment.fills[0].boundVariables.color.id = op.destination.id;
      }
    }
    eq(field(observed, op), field(exp, op), 'DESTINATION_SLOT:' + index);
    const dest = (op.field === 'effectStyleId' ? after.styles : after.variables).find(v => v.id === op.destination.id);
    check(dest?.key === op.destination.key && dest.remote === false, 'DESTINATION_LOCALITY:' + index);
  }

  // Preserve raw mode differences as evidence; compare semantics only through proven collection pairs.
  function normalizeModes(rows, capture, label) {
    const collections = new Map(capture.collections.map(v => [v.id, v]));
    for (const row of rows) {
      const mapped = new Map();
      for (const [id, modeId] of Object.entries(row.properties.resolvedVariableModes)) {
        const c = collections.get(id), mode = c?.modes.find(m => m.modeId === modeId);
        if (!check(!!c && !!mode, 'UNKNOWN_RESOLVED_MODE', { label, nodeId: row.id, id, modeId })) continue;
        const key = collectionPairs[c.key] || c.key;
        check(!mapped.has(key) || mapped.get(key) === mode.name, 'CONFLICTING_MODE', { label, nodeId: row.id, key }); mapped.set(key, mode.name);
      }
      row.properties.resolvedVariableModes = [...mapped].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0);
    }
  }
  for (const row of before.nodes) {
    const other = now.get(row.id); if (!other) continue;
    if (canonical(row.properties.resolvedVariableModes) !== canonical(other.properties.resolvedVariableModes)) representations.push({ nodeId: row.id, path: row.path, property: 'resolvedVariableModes', before: row.properties.resolvedVariableModes, after: other.properties.resolvedVariableModes });
  }
  const observed = clone(after.nodes); normalizeModes(expected, before, 'before'); normalizeModes(observed, after, 'after');
  for (let i = 0; i < Math.max(expected.length, observed.length); i++) eq(observed[i], expected[i], 'PROTECTED_NODE_EXACT:' + (expected[i]?.id || i));
  const expectedDigest = digest(expected), actualDigest = digest(observed);
  eq(apply.protectedNodes, { expectedDigest, actualDigest, ok: expectedDigest === actualDigest }, 'INDEPENDENT_PROTECTED_DIGEST');
  for (const op of manifest.inheritedPreserved) {
    const row = old.get(op.nodeId), other = now.get(op.nodeId);
    eq(field(other, op), field(row, op), 'INHERITED_RAW_SLOT:' + op.nodeId + ':' + op.field);
  }
  const emptyId = manifest.preservedEmptyOverride.nodeId;
  eq(now.get(emptyId).properties.fills, [], 'EMPTY_FILLS_OVERRIDE_PRESERVED');

  // Every captured asset is checked by exact ID, including values, aliases, scopes, codeSyntax, modes and remote.
  for (const kind of ['variables', 'collections', 'styles']) {
    const permitted = new Map([...before[kind], ...targets[kind]].map(v => [v.id, v]));
    eq(new Set(after[kind].map(v => v.id)).size, after[kind].length, 'UNIQUE_ASSET_IDS:' + kind);
    for (const value of after[kind]) eq(value, permitted.get(value.id), 'FULL_ASSET_METADATA:' + kind + ':' + value.id);
    const expectedSummary = after[kind].map(v => ({ id: v.id, key: v.key, name: v.name, remote: v.remote, type: kind === 'variables' ? v.resolvedType : kind === 'collections' ? 'COLLECTION' : v.type })).sort((a,b) => a.id.localeCompare(b.id));
    eq([...after.summary[kind]].sort((a,b) => a.id.localeCompare(b.id)), expectedSummary, 'SUMMARY_ASSETS:' + kind);
  }
  const usedVariables = new Set();
  const addAliases = value => walk(value, v => { if (v.type === 'VARIABLE_ALIAS') usedVariables.add(v.id); });
  addAliases(after.nodes); addAliases(after.styles);
  const directIds = new Set(usedVariables), variables = new Map(after.variables.map(v => [v.id, v]));
  for (const id of usedVariables) { const value = variables.get(id); if (check(!!value, 'UNKNOWN_ALIAS_TARGET', id)) addAliases(value.valuesByMode); }
  eq(sorted(usedVariables), sorted(after.variables.map(v => v.id)), 'EXACT_VARIABLE_CLOSURE');
  const usedStyles = new Set(); walk(after.nodes, v => { for (const [k, id] of Object.entries(v)) if (/StyleId$/.test(k) && typeof id === 'string' && id) usedStyles.add(id); });
  eq(sorted(usedStyles), sorted(after.styles.map(v => v.id)), 'EXACT_STYLE_USAGE');
  const usedCollections = new Set(after.variables.map(v => v.variableCollectionId));
  for (const n of after.nodes) for (const k of ['resolvedVariableModes', 'explicitVariableModes']) for (const id of Object.keys(n.properties[k])) usedCollections.add(id);
  eq(sorted(usedCollections), sorted(after.collections.map(v => v.id)), 'EXACT_COLLECTION_USAGE');
  const expectedSummary = clone(before.summary);
  for (const kind of ['variables', 'collections', 'styles']) { expectedSummary[kind] = after.summary[kind]; expectedSummary.counts[kind] = after[kind].length; }
  eq(after.summary, expectedSummary, 'SUMMARY_SCOPE_EXACT');

  const mutationIds = [...new Set(input.operations.map(o => o.nodeId))];
  eq(apply.status, 'verified', 'LIVE_APPLY_STATUS'); eq(apply.operationCount,112,'LIVE_OPERATION_COUNT'); eq(apply.errors, [], 'LIVE_APPLY_ERRORS'); eq(apply.createdNodeIds, [], 'LIVE_CREATED'); eq(apply.unknownMutations, false, 'LIVE_UNKNOWN_MUTATIONS'); eq(apply.inFlight,null,'LIVE_IN_FLIGHT');
  eq(apply.mutatedNodeIds, mutationIds, 'EXACT_MUTATED_IDS'); eq(apply.attemptedNodeIds, mutationIds, 'EXACT_ATTEMPTED_IDS');
  eq(apply.trace.length,112,'LIVE_TRACE_COUNT'); eq(apply.readBack.length,112,'LIVE_READBACK_COUNT');
  for (const [index, op] of input.operations.entries()) {
    eq(apply.trace[index], { index, nodeId: op.nodeId, field: op.field, indexInPaints: op.index, destinationKey: op.destination.key, status: 'completed' }, 'LIVE_TRACE:' + index);
    eq(apply.readBack[index], { index, nodeId: op.nodeId, field: op.field, valueDigest: digest(field(now.get(op.nodeId), op)), asset: { id: op.destination.id, key: op.destination.key, remote: false }, ok: true }, 'LIVE_READBACK:' + index);
  }
  eq(apply.afterSnapshotDigest, digest(normalizeSnapshot(after)), 'SEPARATE_CAPTURE_MATCHES_LIVE_AFTER');
  eq(apply.baselineSnapshotDigest, input.expectedSnapshotDigest, 'LIVE_BASELINE');
  for (const k of ['summary','nodes','variables','collections','styles','references']) eq(apply.afterPartDigests[k], digest(normalizeSnapshot(after)[k]), 'LIVE_AFTER_PART:' + k);
  eq(dry.status,'dry-run-passed','LIVE_DRY_STATUS'); eq(dry.mutatedNodeIds,[],'LIVE_DRY_NO_WRITES'); eq(dry.attemptedNodeIds,[],'LIVE_DRY_NO_ATTEMPTS'); eq(dry.createdNodeIds,[],'LIVE_DRY_NO_CREATES'); eq(dry.errors,[],'LIVE_DRY_ERRORS'); eq(dry.baselineSnapshotDigest,input.expectedSnapshotDigest,'LIVE_DRY_BASELINE');
  for (const [label, envelope, result] of [['apply',applyEnvelope,apply],['dry',dryEnvelope,dry]]) {
    try {
      eq(envelope.codec,'gzip-base64','ENVELOPE_CODEC:' + label);
      const gzip = Buffer.from(envelope.payload,'base64'), raw = gunzipSync(gzip,{maxOutputLength:8*1024*1024});
      eq(gzip.length,envelope.gzipBytes,'ENVELOPE_GZIP_BYTES:' + label); eq(raw.length,envelope.utf8Bytes,'ENVELOPE_UTF8_BYTES:' + label); eq(sha(raw),envelope.sha256,'ENVELOPE_SHA:' + label); eq(JSON.parse(raw.toString('utf8')),result,'ENVELOPE_DECODED_RESULT:' + label);
      for(const k of ['createdNodeIds','mutatedNodeIds','attemptedNodeIds','unknownMutations','status']) eq(envelope[k],result[k],'ENVELOPE_OUTER:' + label + ':' + k);
    } catch(error) { check(false,'ENVELOPE_DECODE_FAILURE:' + label,String(error.message)); }
  }
  // This later display-only operation is recorded separately; it is not folded into the full-snapshot proof.
  eq(translation.fileKey,input.fileKey,'DISPLAY_FILE'); eq(translation.rootId,input.rootId,'DISPLAY_ROOT'); eq(translation.createdNodeIds,[],'DISPLAY_NO_CREATES'); eq(translation.mutatedNodeIds,[input.rootId],'DISPLAY_ROOT_ONLY');
  eq(translation.before,Object.fromEntries(['x','y','width','height'].map(k=>[k,now.get(input.rootId).geometry[k]])),'DISPLAY_BEFORE'); eq(translation.after,{x:1600,y:0,width:1440,height:900},'DISPLAY_APPROVED_TRANSLATION');

  const remote = after.variables.filter(v=>v.remote), remoteDirect=remote.filter(v=>directIds.has(v.id));
  const preservedIds = new Set(manifest.inheritedPreserved.map(o=>o.source.id));
  eq(sorted(remoteDirect.map(v=>v.id)),sorted(preservedIds),'REMAINING_REMOTE_DIRECT_IS_INHERITED_ONLY');
  checks.push('112 exact approved slots plus guarded mirrors', '413 full node rows including hidden/text/font/geometry/main/override fields', '129 inherited raw slots', 'empty fills override', 'full asset metadata and alias closure', 'same-key handle locality', 'live trace/readback/envelope digests', 'later display-only translation recorded separately');
  return { ok:differences.length===0, scope:'TEST P2 reference rebind only; not formal E4 or full51-owner completion', differences, unresolved:[], representations, checks,
    counts:{nodes:after.nodes.length,instances:after.nodes.filter(n=>n.type==='INSTANCE').length,text:after.nodes.filter(n=>n.text).length,hidden:after.nodes.filter(n=>n.geometry.visible===false).length,overrideRows:after.nodes.reduce((sum,n)=>sum+(n.componentProperties?.overrides?.length||0),0),operations:input.operations.length,mutatedNodes:mutationIds.length,inheritedPreserved:manifest.inheritedPreserved.length,variables:after.variables.length,localVariables:after.variables.filter(v=>!v.remote).length,remoteVariables:remote.length,remoteDirectVariables:remoteDirect.length,styles:after.styles.length,localStyles:after.styles.filter(v=>!v.remote).length,representationChanges:representations.length},
    afterSnapshotDigest:digest(normalizeSnapshot(after)),protectedNodes:{expectedDigest,actualDigest},
    remainingRemote:{note:'Inherited from the38 unmoved instances; no unknown direct reference write is excused',variables:remote.map(v=>({id:v.id,key:v.key,name:v.name,role:directIds.has(v.id)?'inherited-slot':'alias-dependency'})),instances:after.nodes.filter(n=>n.main?.remote).map(n=>({id:n.id,path:n.path,main:n.main}))},displayOnlyAfterCapture:translation };
}

if(process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href) {
  const result=verifyFinal(loadEvidence());
  writeFileSync(p('e4-recopy-final.classified.json'),JSON.stringify(result,null,2)+'\n');
  process.stdout.write(JSON.stringify({ok:result.ok,counts:result.counts,differences:result.differences.length,unresolved:result.unresolved.length,firstDifferences:result.differences.slice(0,2)},null,2)+'\n');
  if(!result.ok) process.exitCode=1;
}
