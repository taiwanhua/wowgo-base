<!-- 發送前：附上本輪 captures、foundation proof、比較器／測試與結果的證據包，並把附件連結放在「重現與證據」；目前尚未上傳，勿把本機 .codex 路徑當成公共驗收證據。下列測試結論與 Figma 導航可直接核對。 -->

E4 仍在 TEST 隔離驗收，**尚未完成正式拆分；正式 CookHome 零寫入**。

本輪使用 [TEST Source](https://www.figma.com/design/TJukM19dakT0GsHSNeja36) 與 [TEST Destination](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja)，沒有重建或 detach 既有 instances。

**已驗證**

- 原生 Duplicate 保留 65 variables、4 collections、15 text styles、15 effect styles 的完整 metadata；新 keys 有明確對照，alias 留在自己的檔案。
- Button／Badge／Tab／Tabs 原生 MOVE、發布及 foundations 重綁通過：144 節點的結構、文字、幾何與覆寫無差異。[MOVE 發布](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?version-id=2406310665196479109&node-id=7-304)／[巢狀依賴補發](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?version-id=2406340820141053476&node-id=7-304)／[foundations 發布](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?version-id=2406383688204541022&node-id=7-304)。
- 補驗 NavItem、NavGroup、AdminSideNav 三個 owners 的依賴閉包（含 Badge）：149 節點、40 instances、46 文字、28 隱藏節點，原生 MOVE 後按核准 keys 重綁 26 個欄位（23 直接欄位、3 既有覆寫）；40 mains、19 variables、4 collections、1 style 全部 local。[MOVE 發布](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?version-id=2406345815191238713&node-id=32-2)／[26 欄位重綁發布](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?version-id=2406343535102026740&node-id=32-2)。
- 原始來源→重綁完成、搬移後→重綁完成兩組比較，語義差異／locality 差異／未解決項均 **0**。文字、字型、style、Light／Dark values、alias、mode 與 21 筆既有 override 保留；沒有新增 explicit mode。35 項檢查＋39 項回歸通過，另一位唯讀 reviewer 獨立比對一致。
- 三個 owners 的重綁已發布（3 個 Modified）；Source 已跨頁接受 31 個 SideNav、3 個 NavItem、16 個 NavGroup 的更新。完整 after 快照之後，僅將 Destination NavItem 根座標調到 `(400,-300)`、NavGroup 根座標調到 `(400,-200)`，方便排列；SideNav 未移動。上述「幾何無差異」結論對應重排前的快照，不能當成目前根座標不變。

| 目前 Destination 節點 | 原 Source → Destination ID |
| --- | --- |
| [NavItem](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?node-id=4023-2) | `20:18 → 4023:2` |
| [NavGroup](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?node-id=4023-7) | `25:41 → 4023:7`；variants `25:33 → 4023:8`、`25:37 → 4023:12` |
| [AdminSideNav](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?node-id=4023-17) | `30:52 → 4023:17` |

第一次 [413 節點 reference copy](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?node-id=4018-172) 保留文字、幾何與覆寫，但當時仍有 17 個 Badge 經未搬的 Sidebar 依賴呈 remote，因此沒有算通過；同 key 的 remote／local handle 與 mode 表示差異亦完整保留，沒有靠忽略差異過關。

三個 owners 補搬、重綁與 Source 接受後，[Source Screen `44:45`](https://www.figma.com/design/TJukM19dakT0GsHSNeja36?node-id=44-45) → [第二次 copy `4029:264`](https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja?node-id=4029-264) 已通過：413 節點、84 instances、136 文字、37 隱藏節點，內容／locality／未解決差異皆 **0**；24 筆 override rows 保留，圖片引用前後皆 0。唯一核准幾何變更是整個 root `(0,0) → (0,34)`。全部 46 個已搬實例為 local，38 個未搬實例依預期為 remote；原 17 個 nested Badge 已全部回 local。

38 個 remote 分別為 AdminAppBar＋orgSwitcher 2、AdminRouteTabs＋其 tabs 10、Select／Tag／Link 4、Checkbox 22，來源 keys 不變。它們不是斷鏈，也不以直接改 nested instances 取代後續 owner 搬移。讀取中曾遇工具限制訊息，正常冷卻後已恢復；完整欄位壓縮傳輸的 TEST 唯讀回傳均已通過解壓、SHA 與 bytes 核對。

傳輸候選另以舊 before／after 各 413 節點執行離線 Figma fixture：每份 5 次 nodes＋1 次全 assets，解壓後逐欄相同，hidden descendants 與無原生 TextEncoder 的中文／emoji 保留；損壞 gzip、bytes、SHA 均拒絕。assets 外層清單按 exact ID 核對，清單枚舉次序不當作資產身分，內部 modes／values／overrides 陣列仍逐項保留。此測試只驗傳輸完整性，不能替代搬移或複製驗收。

**Reference foundations 重綁已驗證**

真實 dry 通過後，對第二次 copy 恰執行一次 **112 處**重綁：105 個直接變數綁定（74 fills、3 strokes、28 四角）＋5 個既有 fills override＋2 個 Shadow/Card；86 個節點被寫入、零新建，112 個 setter 完成且 112 個 readback 正確。129 處繼承綁定保持原值，側欄第六個空 fills override 保留；69 個涉及 fills 的 TEXT 沒有新增 text style。

另行重收的完整 413 節點 after 與 apply 內部快照 SHA-256 完全一致（`b48bdb9c…adf3870`）。精確逐 slot／鏡像核對為 **0 差異、0 未解決項**；24 筆覆寫、hidden、文字／字型／幾何／main 身分及完整資產 metadata 保留。123 筆 resolved mode 的表示變化留在報告中；沒有放寬 Light／Dark、alias、explicit mode 或 locality。32 項實錄／負向測試通過，包含「繼承綁定換成同色本地變數仍失敗」，另有生成腳本 14 項測試。

目前資產為 55 variables（29 local、26 remote）、8 collections（4 local、4 remote）、3 styles 全 local。16 個直接被引用的 remote variable 全屬上述 129 處繼承綁定，其餘 10 個是 alias 依賴；38 個尚未搬 owner 的 remote instances 保留，不能宣稱整張畫面已零反向依賴。七個已搬 owners 與 reference 的精確重綁路線已完成這輪 TEST 驗證，仍不能代替正式 51 owners／90 references 的全量盤點與遷移。

最後視覺核對通過。完整 after 快照後，僅將 reference root `4029:264` 從 `(0,34)` 平移到 `(1600,0)`，尺寸維持 `1440×900`，避免與第一次 copy 重疊；此排版另留原始結果，不把排版後位置說成未變。全量 51 owners、正式拆分、正式專案接軌仍未完成，F 尚未開始。

**重現與證據**

依上列 TEST 檔案、node IDs 與原生發布版本連結定位；在唯讀快照中包含 hidden descendants，以 exact child path 對照節點，component MOVE keys 與 foundation keys 只用已記錄的來源／目的對照。數值容差 `1e-6`；除原生搬移的根座標平移外，結構、文字、幾何、styles、aliases、modes、properties 與 overrides 都須逐項相等，未知身分及 locality 不符合即失敗。

證據包解開後依 `README.md` 執行：`node e4-closure-final.tests.mjs`（35＋39 檢查）、`node e4-validate-recopy.mjs`（重現 copy 比較及歷史 proposed manifest）、`node e4-recopy-final.tests.mjs`（32 檢查）與 `node e4-verify-recopy-final.mjs`（完整 final 精確比較）。包內另含生成腳本 14 項 fixture 測試、14 個實際傳輸 envelope 核對與 live dry/apply 的完整 trace。全用 Node 內建模組，已在獨立資料夾重跑；不依賴作者工作樹、本機絕對路徑或 npm 安裝。附件與本留言保存測試過程；正式操作及維護規則仍回既有版控文件，不另以本機 scratch 維護一套正本。
