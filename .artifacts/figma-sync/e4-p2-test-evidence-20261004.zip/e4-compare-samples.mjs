/** One-time E4 comparison; never writes Figma or input files. Final rebound state only.
 * CLI: node e4-compare-samples.mjs BEFORE AFTER FOUNDATIONS APPROVALS
 * APPROVALS: {destinationPageId, roots:[{sourceId,destinationId}],
 * componentProperties:[{sourceOwnerId,sourceKey,destinationKey}]}
 * Root translations are allowed and reported; rotation, size and all descendant geometry are not.
 * Full property-key mappings must be observed/approved; no suffix stripping or name matching.
 */
import { readFileSync } from "node:fs";
import { pathToFileURL } from "node:url";

const clone = (value) => structuredClone(value);
const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const pathKey = (rootId, path) => rootId + "/" + path.join("/");
const styleFields = new Set(["textStyleId", "fillStyleId", "strokeStyleId", "effectStyleId", "gridStyleId"]);
const brief = (value) => value === undefined ? { absent: true } : value;

export function compareSamples({ before, after, foundations, approvals }) {
  const diffs = [], unresolved = [], mappings = { nodes: [], components: [], properties: [], translations: [] };
  function diff(at, expected, actual, code = "VALUE_CHANGED") { diffs.push({ at, code, expected: brief(expected), actual: brief(actual) }); }
  function compare(a, b, at) {
    if (typeof a === "number" && typeof b === "number") {
      if (!Number.isFinite(a) || !Number.isFinite(b) || Math.abs(a - b) > 1e-6) diff(at, a, b);
      return;
    }
    if (a === b) return;
    if (!a || !b || typeof a !== "object" || typeof b !== "object" || Array.isArray(a) !== Array.isArray(b)) { diff(at, a, b); return; }
    if (Array.isArray(a)) {
      if (a.length !== b.length) diff(at + "/length", a.length, b.length);
      for (let i = 0; i < Math.min(a.length, b.length); i += 1) compare(a[i], b[i], at + "/" + i);
      return;
    }
    const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])].sort();
    for (const key of keys) {
      if (!own(a, key) || !own(b, key)) diff(at + "/" + key, a[key], b[key], "FIELD_CHANGED");
      else compare(a[key], b[key], at + "/" + key);
    }
  }
  function requireThat(ok, at, detail) { if (!ok) unresolved.push({ at, detail }); return ok; }
  function unique(rows, key, at) {
    const out = new Map();
    for (const item of rows) {
      const id = key(item);
      if (out.has(id)) compare(out.get(id), item, at + "/duplicate/" + id);
      else out.set(id, item);
    }
    return out;
  }
  function bundle(value, side) {
    const groups = value.summary ? [value] : Object.values(value);
    const all = { groups, nodes: [], variables: [], collections: [], styles: [], roots: [], ancestors: [] };
    for (const [i, group] of groups.entries()) {
      const at = side + "/group/" + i;
      if (!requireThat(group && group.summary && Array.isArray(group.nodes), at, "Need assembled probe group: summary plus complete nodes/variables/collections/styles/references arrays")) continue;
      compare(group.summary.errors, [], at + "/errors");
      compare(group.summary.createdNodeIds, [], at + "/createdNodeIds");
      compare(group.summary.mutatedNodeIds, [], at + "/mutatedNodeIds");
      for (const name of ["nodes", "variables", "collections", "styles", "references"]) {
        if (!requireThat(Array.isArray(group[name]), at + "/" + name, "Missing complete probe part")) continue;
        if (name !== "references") {
          compare(group[name].length, group.summary.counts[name], at + "/complete/" + name);
          all[name].push(...group[name]);
        }
      }
      all.roots.push(...group.summary.roots);
      all.ancestors.push(...group.summary.ancestors);
      compare(group.summary.counts.instances, group.nodes.filter((n) => n.type === "INSTANCE").length, at + "/instances");
      compare(group.summary.counts.text, group.nodes.filter((n) => n.type === "TEXT").length, at + "/text");
      compare(group.summary.counts.reactions, group.nodes.reduce((n, row) => n + (row.properties.reactions || []).length, 0), at + "/reactions");
      const expectedFile = side === "before" ? foundations.sourceFileKey : foundations.destinationFileKey;
      compare(group.summary.fileKey, expectedFile, at + "/fileKey");
      if (side === "after") compare(group.summary.pageId, approvals.destinationPageId, at + "/pageId");
    }
    for (const name of ["nodes", "variables", "collections", "styles", "roots", "ancestors"]) all[name] = unique(all[name], (row) => row.id, side + "/" + name);
    return all;
  }
  if (!requireThat(foundations && foundations.maps && Array.isArray(foundations.diffs), "foundations", "Need the native-copy proof with approved exact maps")) return { ok: false, diffs, unresolved, mappings };
  compare(foundations.diffs, [], "foundations/diffs");
  if (!requireThat(approvals && approvals.destinationPageId && Array.isArray(approvals.roots), "approvals", "Need destinationPageId and explicit root pairs")) return { ok: false, diffs, unresolved, mappings };
  const left = bundle(before, "before"), right = bundle(after, "after");
  const nodeIds = new Map(), componentKeys = new Map(), parents = new Map(), properties = new Map();
  const variableIds = new Map(), variableKeys = new Map(), collectionIds = new Map(), collectionKeys = new Map(), modes = new Map();
  const styleIds = new Map(), styleKeys = new Map();
  function add(map, from, to, at) {
    if (!requireThat(typeof from === "string" && typeof to === "string", at, "Missing exact identity")) return;
    if (map.has(from)) compare(map.get(from), to, at + "/ambiguous");
    map.set(from, to);
  }
  for (const pair of foundations.maps.variables) {
    add(variableIds, pair.source.id, pair.destination.id, "variableId");
    add(variableKeys, pair.source.key, pair.destination.key, "variableKey");
  }
  for (const pair of foundations.maps.collections) {
    add(collectionIds, pair.source.id, pair.destination.id, "collectionId");
    add(collectionKeys, pair.source.key, pair.destination.key, "collectionKey");
    compare(pair.source.modes.length, pair.destination.modes.length, "modes/length");
    for (let i = 0; i < pair.source.modes.length; i += 1) {
      const sourceMode = pair.source.modes[i], destinationMode = pair.destination.modes[i];
      if (!requireThat(destinationMode && sourceMode.name === destinationMode.name, "modes/" + pair.source.key, "Approved native-copy modes must have identical order/name")) continue;
      add(modes, pair.source.id + "|" + sourceMode.modeId, destinationMode.modeId, "modeId");
    }
  }
  for (const pair of foundations.maps.textStyles.concat(foundations.maps.effectStyles)) {
    add(styleIds, pair.source.id, pair.destination.id, "styleId");
    add(styleKeys, pair.source.key, pair.destination.key, "styleKey");
  }
  function translated(map, value, at) {
    if (value === null || value === "" || value === "__FIGMA_MIXED__") return value;
    if (!map.has(value)) { unresolved.push({ at, detail: "No explicit identity mapping", value }); return value; }
    return map.get(value);
  }
  const roots = new Map();
  for (const pair of approvals.roots) {
    const oldRoot = left.nodes.get(pair.sourceId), newRoot = right.nodes.get(pair.destinationId);
    if (!requireThat(oldRoot && newRoot && oldRoot.path.length === 0 && newRoot.path.length === 0, "root/" + pair.sourceId, "Both explicit roots must exist as root observations")) continue;
    requireThat(!roots.has(pair.sourceId), "root/" + pair.sourceId, "Duplicate source root approval");
    roots.set(pair.sourceId, pair.destinationId);
    compare(newRoot.parentId, approvals.destinationPageId, "root/" + pair.sourceId + "/parent");
    add(parents, oldRoot.parentId, newRoot.parentId, "parentId");
    const oldRows = [...left.nodes.values()].filter((n) => n.rootId === pair.sourceId);
    const newRows = [...right.nodes.values()].filter((n) => n.rootId === pair.destinationId);
    const byPath = unique(newRows, (row) => pathKey(pair.destinationId, row.path), "destination-path");
    compare(oldRows.length, newRows.length, "root/" + pair.sourceId + "/nodeCount");
    for (const old of oldRows) {
      const now = byPath.get(pathKey(pair.destinationId, old.path));
      if (!requireThat(now, "node/" + old.id, "Missing node at approved root's exact structural path")) continue;
      compare(old.type, now.type, "structure/" + old.id + "/type");
      compare(old.name, now.name, "structure/" + old.id + "/name");
      compare(old.childIds.length, now.childIds.length, "structure/" + old.id + "/childCount");
      add(nodeIds, old.id, now.id, "nodeId");
      mappings.nodes.push({ sourceId: old.id, destinationId: now.id, sourceRootId: pair.sourceId, path: old.path });
      if (old.type === "COMPONENT" || old.type === "COMPONENT_SET") {
        add(componentKeys, old.key, now.key, "componentKey");
        mappings.components.push({ sourceId: old.id, destinationId: now.id, sourceKey: old.key, destinationKey: now.key });
      }
    }
  }
  compare([...left.roots.keys()].sort(), [...roots.keys()].sort(), "approved-source-roots");
  compare([...right.roots.keys()].sort(), [...roots.values()].sort(), "approved-destination-roots");
  compare(new Set(nodeIds.values()).size, nodeIds.size, "node-map-injective");
  const propertyPairs = approvals.componentProperties || [];
  for (const old of left.nodes.values()) {
    if (!old.componentPropertyDefinitions) continue;
    const now = right.nodes.get(nodeIds.get(old.id));
    if (!now) continue;
    for (const sourceKey of Object.keys(old.componentPropertyDefinitions)) {
      const explicit = propertyPairs.filter((entry) => entry.sourceOwnerId === old.id && entry.sourceKey === sourceKey);
      requireThat(explicit.length <= 1, "property/" + old.id + "/" + sourceKey, "Duplicate property approval");
      const destinationKey = explicit[0]?.destinationKey || sourceKey;
      if (!own(now.componentPropertyDefinitions || {}, destinationKey)) {
        unresolved.push({ at: "property/" + old.id, sourceKey, detail: "Supply full observed sourceKey→destinationKey with sourceOwnerId", observedDestinationKeys: Object.keys(now.componentPropertyDefinitions || {}) });
        continue;
      }
      add(properties, sourceKey, destinationKey, "propertyKey");
      mappings.properties.push({ sourceOwnerId: old.id, destinationOwnerId: now.id, sourceKey, destinationKey });
    }
  }
  for (const pair of propertyPairs) requireThat(mappings.properties.some((p) => p.sourceOwnerId === pair.sourceOwnerId && p.sourceKey === pair.sourceKey && p.destinationKey === pair.destinationKey), "propertyApproval", "Unused or invalid property mapping: " + JSON.stringify(pair));

  function propertyIdentity(value, at) { return translated(properties, value, at); }
  function componentIdentity(value, at) {
    if (nodeIds.has(value)) return nodeIds.get(value);
    return translated(componentKeys, value, at);
  }
  function modeObject(value, at) {
    const out = {};
    for (const [id, mode] of Object.entries(value || {})) out[translated(collectionIds, id, at)] = translated(modes, id + "|" + mode, at + "/mode");
    return out;
  }
  function rewrite(value, at = "value") {
    if (!value || typeof value !== "object") return value;
    if (Array.isArray(value)) return value.map((item, index) => rewrite(item, at + "/" + index));
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      const next = at + "/" + key;
      if (value.type === "VARIABLE_ALIAS" && key === "id") out[key] = translated(variableIds, item, next);
      else if (styleFields.has(key)) out[key] = translated(styleIds, item, next);
      else if (key === "explicitVariableModes" || key === "resolvedVariableModes") out[key] = modeObject(item, next);
      else if (key === "componentPropertyReferences" && item) out[key] = Object.fromEntries(Object.entries(item).map(([field, prop]) => [field, propertyIdentity(prop, next + "/" + field)]));
      else if (key === "variableId") out[key] = translated(variableIds, item, next);
      else if (key === "variableCollectionId") out[key] = translated(collectionIds, item, next);
      else if (key === "variableModeId" && value.variableCollectionId) out[key] = translated(modes, value.variableCollectionId + "|" + item, next);
      else if (key === "destinationId") out[key] = translated(nodeIds, item, next);
      else out[key] = rewrite(item, next);
    }
    return out;
  }
  function propertyRecord(value, at, definition) {
    const result = {};
    for (const [key, entry] of Object.entries(value || {})) {
      const mapped = propertyIdentity(key, at);
      const row = rewrite(entry, at + "/" + key);
      const field = definition ? "defaultValue" : "value";
      if (entry.type === "INSTANCE_SWAP" && typeof entry[field] === "string") row[field] = componentIdentity(entry[field], at + "/" + field);
      if (Array.isArray(entry.preferredValues)) row.preferredValues = entry.preferredValues.map((item) => ({ ...item, key: translated(componentKeys, item.key, at + "/preferredValues") }));
      result[mapped] = row;
    }
    return result;
  }
  for (const old of left.nodes.values()) {
    const now = right.nodes.get(nodeIds.get(old.id));
    if (!now) continue;
    const expected = rewrite(old, "node/" + old.id);
    expected.id = nodeIds.get(old.id); expected.rootId = translated(roots, old.rootId, "rootId");
    expected.parentId = old.path.length === 0 ? translated(parents, old.parentId, "parentId") : translated(nodeIds, old.parentId, "parentId");
    expected.childIds = old.childIds.map((id) => translated(nodeIds, id, "childId"));
    if (own(old, "key")) expected.key = translated(componentKeys, old.key, "componentKey");
    if (old.main) expected.main = { ...old.main, id: translated(nodeIds, old.main.id, "main/id"), key: translated(componentKeys, old.main.key, "main/key") };
    if (old.componentPropertyDefinitions) expected.componentPropertyDefinitions = propertyRecord(old.componentPropertyDefinitions, "definitions/" + old.id, true);
    if (old.componentProperties) {
      expected.componentProperties.componentProperties = propertyRecord(old.componentProperties.componentProperties, "instanceProperties/" + old.id, false);
      if (Array.isArray(old.componentProperties.overrides)) expected.componentProperties.overrides = old.componentProperties.overrides.map((row) => ({ ...row, id: translated(nodeIds, row.id, "override/id") }));
    }
    if (old.path.length === 0) {
      mappings.translations.push({ sourceId: old.id, destinationId: now.id, before: { x: old.geometry.x, y: old.geometry.y }, after: { x: now.geometry.x, y: now.geometry.y } });
      expected.geometry.x = now.geometry.x; expected.geometry.y = now.geometry.y;
      if (expected.geometry.relativeTransform && now.geometry.relativeTransform) {
        expected.geometry.relativeTransform[0][2] = now.geometry.x;
        expected.geometry.relativeTransform[1][2] = now.geometry.y;
      }
    }
    compare(expected, now, "node/" + old.id);
  }
  function compareAssets(name, idMap, keyMap) {
    const expectedIds = [];
    for (const old of left[name].values()) {
      const id = translated(idMap, old.id, name + "/id"); expectedIds.push(id);
      const now = right[name].get(id);
      if (!requireThat(now, name + "/" + old.id, "Missing approved destination asset in actual used-asset closure")) continue;
      const expected = rewrite(old, name + "/" + old.id);
      expected.id = id; expected.key = translated(keyMap, old.key, name + "/key");
      compare(now.remote, false, name + "/" + old.id + "/must-be-local");
      if (name === "variables") {
        const values = {};
        for (const [modeId, value] of Object.entries(old.valuesByMode)) values[translated(modes, old.variableCollectionId + "|" + modeId, "variable/mode")] = rewrite(value);
        expected.valuesByMode = values;
      }
      if (name === "collections") {
        expected.defaultModeId = translated(modes, old.id + "|" + old.defaultModeId, "collection/defaultMode");
        expected.modes = old.modes.map((mode) => ({ ...mode, modeId: translated(modes, old.id + "|" + mode.modeId, "collection/mode") }));
      }
      compare(expected, now, name + "/" + old.id);
    }
    compare([...new Set(expectedIds)].sort(), [...right[name].keys()].sort(), name + "/exact-used-assets");
  }
  compareAssets("variables", variableIds, variableKeys);
  compareAssets("collections", collectionIds, collectionKeys);
  compareAssets("styles", styleIds, styleKeys);
  // Explicit ancestor modes are checked; changing page names/location is permitted, not changing inherited semantics.
  for (const old of left.ancestors.values()) {
    const id = parents.get(old.id);
    if (!requireThat(id, "ancestor/" + old.id, "Unmapped ancestor; this sample comparator only approves direct-page root moves")) continue;
    const now = right.ancestors.get(id);
    if (!requireThat(now, "ancestor/" + old.id, "Destination ancestor observation missing")) continue;
    compare(old.type, now.type, "ancestor/" + old.id + "/type");
    compare(rewrite(old.modes), now.modes, "ancestor/" + old.id + "/modes");
  }
  const uniqueUnresolved = [...new Map(unresolved.map((item) => [JSON.stringify(item), item])).values()];
  return {
    ok: diffs.length === 0 && uniqueUnresolved.length === 0,
    comparison: "E4 four-owner native move + approved local foundation rebinding",
    tolerance: 1e-6,
    counts: { beforeNodes: left.nodes.size, afterNodes: right.nodes.size, mappedNodes: nodeIds.size, mappedComponents: componentKeys.size, diffs: diffs.length, unresolved: uniqueUnresolved.length },
    diffs, unresolved: uniqueUnresolved, mappings,
    limits: ["Only captured probe fields; not a whole-file or general Figma identity proof", "Structural mapping is explicitly scoped to approved four-root native MOVE; no automatic identity adoption", "Extra modes/assets remain diffs, never silently discarded", "Final rebound state expected; an intermediate remote-foundation state is not a passing result"],
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    if (process.argv.length !== 6) throw new Error("Usage: node e4-compare-samples.mjs BEFORE AFTER FOUNDATIONS APPROVALS");
    const [before, after, foundations, approvals] = process.argv.slice(2).map((file) => JSON.parse(readFileSync(file, "utf8")));
    const result = compareSamples({ before, after, foundations, approvals });
    process.stdout.write(JSON.stringify(result, null, 2) + "\n");
    process.exitCode = result.ok ? 0 : 1;
  } catch (error) {
    process.stderr.write(String(error.message).replace(/[\r\n]+/g, " ") + "\n");
    process.exitCode = 2;
  }
}
