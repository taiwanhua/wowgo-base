/** Scratch-only native recopy comparison and exact reference-rebind inventory.
 * Portable within the evidence folder: node e4-validate-recopy.mjs
 * Writes only new recopy approvals, classified report and rebind manifest.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { compareReferenceCopy } from './e4-compare-reference-copy.mjs';
const p = name => new URL('./' + name, import.meta.url);
const read = name => JSON.parse(readFileSync(p(name), 'utf8'));
const hash = name => createHash('sha256').update(readFileSync(p(name))).digest('hex');
const save = (name, value) => writeFileSync(p(name), JSON.stringify(value, null, 2) + '\n');
const names = ['e4-recopy-before.json', 'e4-recopy-after.json', 'e4-reference-approvals.json', 'e4-closure-final.classified.json', 'e4-test-foundations-proof.json'];
const inputSha256 = Object.fromEntries(names.map(n => [n, hash(n)]));
const before = read(names[0]), after = read(names[1]), old = read(names[2]), closure = read(names[3]), proof = read(names[4]);
assert.deepEqual(proof.diffs, []);
const approvals = { ...old, sourceRootId: '44:45', destinationRootId: '4029:264',
  localComponentKeys: [...new Set([...old.localComponentKeys, ...closure.approvals.componentPairs.map(x => x.destinationKey)])] };
assert.equal(Object.hasOwn(approvals, 'foundationProof'), false, 'Copy stage must not approve foundation key changes');
const result = compareReferenceCopy({ before, after, approvals });
assert.equal(result.ok, true, JSON.stringify({ diffs: result.diffs.slice(0, 8), unresolved: result.unresolved.slice(0, 8) }));
assert.equal(result.counts.mappedNodes, 413); assert.equal(result.counts.instances, 84);
const nodes = new Map(after.nodes.map(n => [n.id, n]));
const vars = new Map(after.variables.map(v => [v.id, v])), styles = new Map(after.styles.map(s => [s.id, s]));
const sourceVars = new Map(proof.maps.variables.map(pair => [pair.source.key, pair]));
const sourceStyles = new Map([...proof.maps.textStyles, ...proof.maps.effectStyles].map(pair => [pair.source.key, pair]));
const localKeys = new Set(approvals.localComponentKeys);
const instances = after.nodes.filter(n => n.main);
assert.equal(instances.filter(n => !n.main.remote).length, 46);
assert.equal(instances.filter(n => n.main.remote).length, 38);
const mainGroups = [];
for (const key of [...new Set(instances.map(n => n.main.key))]) {
  const rows = instances.filter(n => n.main.key === key);
  mainGroups.push({ key, remote: rows[0].main.remote, mainName: rows[0].main.name, count: rows.length,
    nodeIds: rows.map(n => n.id), names: [...new Set(rows.map(n => n.name))],
    classification: localKeys.has(key) ? 'moved-owner-local-as-required' : 'unmoved-owner-remote-as-approved-for-copy-stage' });
}
function ancestors(node) {
  const list = [];
  for (let row = node; row; row = nodes.get(row.parentId)) if (row.type === 'INSTANCE') list.push(row);
  return list;
}
function ownership(node, field) {
  const chain = ancestors(node);
  const holders = chain.filter(n => (n.componentProperties?.overrides || []).some(o => o.id === node.id && o.overriddenFields.includes(field)));
  return { category: !chain.length ? 'direct-reference-field' : holders.length ? 'existing-instance-override' : 'inherited-instance-field-do-not-write',
    instanceChain: chain.map(n => ({ id: n.id, key: n.main.key, remote: n.main.remote })),
    existingOverrideHolders: holders.map(n => n.id) };
}
const operations = [], inherited = [], unknown = [];
function variableSlot(node, field, sourceId, index = null) {
  const variable = vars.get(sourceId);
  assert.ok(variable, 'Unknown captured variable ' + sourceId);
  if (!variable.remote) return;
  const pair = sourceVars.get(variable.key);
  if (!pair) { unknown.push({ nodeId: node.id, field, index, sourceId, sourceKey: variable.key }); return; }
  const own = ownership(node, field);
  const row = { nodeId: node.id, path: node.path, nodeType: node.type, field, index,
    source: { id: sourceId, key: variable.key, name: variable.name, remote: true, resolvedType: variable.resolvedType },
    destination: pair.destination, ...own };
  if (index !== null) row.expectedPaint = node.properties[field][index];
  else row.expectedBinding = node.properties.boundVariables[field];
  if (node.text) {
    row.expectedText = node.text;
    assert.equal(node.text.textStyleId, '', 'Do not mutate a styled text without separate evidence');
    assert.notEqual(node.properties[field], '__FIGMA_MIXED__', 'Mixed text paint needs range handling');
    for (const segment of node.text.segments) if (field === 'fills') assert.deepEqual(segment.fills, node.properties.fills, 'Nonuniform text fills need range handling');
  }
  if (own.category === 'inherited-instance-field-do-not-write') inherited.push(row); else operations.push(row);
}
for (const node of after.nodes) {
  for (const [field, binding] of Object.entries(node.properties.boundVariables || {})) {
    if (['fills', 'strokes'].includes(field)) continue; // aggregate mirrors, actual paints below
    assert.ok(['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].includes(field), 'Unreviewed bound field ' + field);
    assert.equal(binding.type, 'VARIABLE_ALIAS'); variableSlot(node, field, binding.id);
  }
  for (const field of ['fills', 'strokes']) {
    const paints = node.properties[field];
    if (paints === undefined) continue;
    assert.ok(Array.isArray(paints), 'Unreviewed mixed paint field');
    paints.forEach((paint, index) => { if (paint.boundVariables?.color) {
      assert.equal(paint.boundVariables.color.type, 'VARIABLE_ALIAS');
      variableSlot(node, field, paint.boundVariables.color.id, index);
    } });
  }
  for (const field of ['fillStyleId', 'strokeStyleId', 'effectStyleId', 'gridStyleId']) {
    const id = node.properties[field]; if (!id || id === '__FIGMA_MIXED__') continue;
    const style = styles.get(id); assert.ok(style, 'Unknown style'); if (!style.remote) continue;
    const pair = sourceStyles.get(style.key); if (!pair) { unknown.push({ nodeId: node.id, field, sourceId: id, sourceKey: style.key }); continue; }
    const own = ownership(node, field);
    const row = { nodeId: node.id, path: node.path, nodeType: node.type, field, source: { id, key: style.key, name: style.name, remote: true, type: style.type }, destination: pair.destination, expectedEffects: node.properties.effects, ...own };
    if (own.category === 'inherited-instance-field-do-not-write') inherited.push(row); else operations.push(row);
  }
}
assert.deepEqual(unknown, []);
const fontNames = [...new Map(operations.filter(x => x.expectedText).flatMap(x => [x.expectedText.fontName, ...x.expectedText.segments.map(s => s.fontName)]).map(f => [JSON.stringify(f), f])).values()];
const emptyOverride = nodes.get('I4029:265;4023:22');
assert.deepEqual(emptyOverride.properties.fills, []);
assert.equal(ownership(emptyOverride, 'fills').category, 'existing-instance-override');
assert.equal(operations.some(x => x.nodeId === emptyOverride.id && x.field === 'fills'), false);
const counts = operations.reduce((sum, x) => { sum[x.category] = (sum[x.category] || 0) + 1; sum.fields[x.field] = (sum.fields[x.field] || 0) + 1; return sum; }, { fields: {} });
const refs = after.nodes.flatMap(n => (n.componentProperties?.overrides || []).map(o => ({ holder: n.id, ...o })));
const uniqueOverrideSlots = [...new Map(refs.flatMap(o => o.overriddenFields.map(field => [{ nodeId: o.id, field }])).map(([slot]) => [slot.nodeId + '/' + slot.field, slot])).values()];
const assetLocality = Object.fromEntries(['variables', 'collections', 'styles'].map(kind => [kind, { total: after[kind].length, local: after[kind].filter(x => !x.remote).length, remote: after[kind].filter(x => x.remote).length }]));
for (const kind of ['variables', 'collections', 'styles']) for (const item of after[kind].filter(x => x.remote)) {
  const pairs = kind === 'variables' ? proof.maps.variables : kind === 'collections' ? proof.maps.collections : [...proof.maps.textStyles, ...proof.maps.effectStyles];
  assert.ok(pairs.some(x => x.source.key === item.key), 'Remote foundation has an unknown source key');
}
const manifest = { stage: 'proposed reference-only foundation rebind; not executed', fileKey: after.summary.fileKey, pageId: after.summary.pageId, rootId: '4029:264',
  inputSha256, foundationMapping: 'e4-test-foundations-proof.json exact source/destination keys',
  capturedExplicitModes: { page: after.summary.ancestors[0].modes, nodes: after.nodes.map(n => ({ nodeId: n.id, explicitVariableModes: n.properties.explicitVariableModes })) },
  counts: { operations: operations.length, ...counts, inheritedPreserved: inherited.length, unknown: unknown.length },
  operations, inheritedPreserved: inherited, unknown, fontNames,
  preservedEmptyOverride: { nodeId: emptyOverride.id, path: emptyOverride.path, field: 'fills', expectedValue: [], ...ownership(emptyOverride, 'fills') },
  guardrails: ['Check full saved after snapshot before the first write, including page explicit modes and original override lists', 'Read actual destination variable/style by approved key and verify local flag, type and full metadata against native foundation proof', 'Load exact captured font names before text paint writes; never apply a text style to an originally unstyled node', 'Write only listed direct fields or already-existing overridden fields; never write inherited rows', 'Preserve paints, all nonbinding fields, text segments, geometry and override holder/node/field lists', 'Do not write aliases, collections, resolvedVariableModes, or source/unmoved masters; they are readonly evidence', 'Validate full post-capture with identity mapping, exact foundation proof only for the approved changed usages; remaining inherited SOURCE bindings are expected until those owners move'] };
for (const n of names) assert.equal(hash(n), inputSha256[n]);
save('e4-recopy-approvals.json', approvals);
save('e4-recopy-rebind-manifest.json', manifest);
save('e4-recopy.classified.json', { stage: 'native recopy before reference foundation rebinding', inputSha256, approvals, comparatorSha256: hash('e4-compare-reference-copy.mjs'), result,
  classification: { copyStagePassed: true, wholeMigrationComplete: false, localInstances: 46, remoteInstances: 38, mainGroups, assetLocality,
    overrideRows: refs.length, uniqueOverriddenFields: uniqueOverrideSlots.length, imagePaints: after.nodes.flatMap(n => [...(n.properties.fills || []), ...(n.properties.strokes || [])]).filter(p => p.type === 'IMAGE').length,
    remainingWork: 'Reference direct fields and existing SOURCE overrides need exact rebinding; inherited fields stay until unmoved owners migrate', rebindManifest: 'e4-recopy-rebind-manifest.json', rebindCounts: manifest.counts } });
process.stdout.write(JSON.stringify({ ok: true, counts: result.counts, assetLocality, manifest: manifest.counts, overrideRows: refs.length, uniqueOverriddenFields: uniqueOverrideSlots.length, fontNames }, null, 2) + '\n');
