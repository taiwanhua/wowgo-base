# E4 P2 TEST evidence

這是 issue #24 的隔離測試證據，不是正式 E4 發布或新的維護文件正本。正式 CookHome 未在本輪寫入。

TEST Source: https://www.figma.com/design/TJukM19dakT0GsHSNeja36

TEST Destination: https://www.figma.com/design/aXrbonVJXIMjSz5RTg0Jja

檔案清單、逐檔 SHA-256 與成功命令見 `e4-p2-evidence-manifest.json`。`e4-p2-status-comment.md` 含可點原生發布版本／node 連結與已驗、未驗界線。原始 before/after、舊失敗報告保留；未覆寫成通過。

## 離線重現

使用 Node.js 20 以上，在解壓後資料夾執行。只使用 Node 內建模組，不需 npm install、作者工作樹、Figma、GitHub 或網路。執行會重新產生部分報告；原始快照不改。

```sh
node e4-compare-samples.mjs e4-sample-before.json e4-sample-after.json e4-test-foundations-proof.json e4-sample-approvals.json
node e4-closure-final.tests.mjs
node e4-validate-recopy.mjs
node e4-recopy-rebind.tests.mjs
node e4-evidence-transport.tests.mjs
node e4-verify-recopy-final.mjs
node e4-recopy-final.tests.mjs
```

第一條驗四 owners；closure 測試含 35 項及原比較器 39 項回歸；reference copy 重現 413 節點／84 instances。最終比較驗 112 個核准欄位、86 個修改節點、129 個原值繼承綁定及空 fills override，最終 32 項測試含失敗控制。保留 123 筆 raw resolved-mode 表示變化；未知 mode／alias／locality 不會忽略。

`e4-recopy-rebind-manifest.json` 是寫入前凍結的 proposed 清單，重跑 copy 驗證仍產生該歷史狀態。真實完成依 `e4-recopy-rebind-apply-result.json` 與 `e4-recopy-final.classified.json` 判定。不要把 proposed 標記誤讀為尚未執行，也不要把原比較失敗改成成功。

`e4-recopy-rebind-dry.js`／`apply.js` 是當次一次性 Figma script 的凍結副本，只供審查及 Node fixture 重播；不要重新貼到 Figma 執行。生成所用 codec 的 MIT notice 已內嵌。產生器依賴 owner 工作樹，所以不列為重現必要檔案；包內腳本與測試都可直接離線執行。

## 範圍

七個 representative owners 的原生 MOVE、發布／接受、foundations 接線，以及一張 consumer→master 檔案的 reference copy 通過本輪 TEST。38 個未搬 owner 實例仍 remote；最終 26 個 remote variables 都屬其繼承／alias closure。這不是正式全量 51 owners／90 references 的零反向依賴證明。

完整比較的幾何以快照為準。之後為排列只移動 closure 的 NavItem／NavGroup roots；reference root 的 `(0,34)→(1600,0)`、尺寸不變見 `e4-recopy-display-translation.json`。後者是獨立操作結果，不是重收完整 live subtree 的快照。
